/*
  V2X WILDLIFE FSU
  Wi-Fi dashboard + USB VFZ1 + SSD1306 OLED + LoRa + active buzzer

  Classic ESP32 / DOIT DevKit V1

  OLED SSD1306 128x64:
    SDA = GPIO21
    SCL = GPIO22
    Address = 0x3C

  Active buzzer signal:
    GPIO27
    Use a suitable driver if required by the buzzer current.

  SX1278:
    SCK=18, MISO=19, MOSI=23
    NSS=5, RST=14, DIO0=26
    433MHz, SF7, BW125kHz, CR4/5, SyncWord 0x52, CRC

  Wi-Fi:
    SSID: V2X-Forest
    Password: V2XForest2026
    Default IP: 192.168.4.1

  Existing dashboard interface:
    GET /status
    POST /frame
    Protocol: VFZ1-WIFI-1

  OLED:
    Animated forest at startup.
    Confirmed display remains until another preset confirms.
    No repeated CHECKING screens between sample windows.

  Buzzer:
    Animal confirmed: one continuous 5-second beep.
    Animal -> non-animal: three short beeps.
    Non-animal -> non-animal: silent.

  INPUT:
    Synthetic dashboard sample windows, not physical animal sensing.
    The dashboard must send live frames for preset changes to reach FSU.
    Noise/quiet clearing is demonstration behavior requested by the user.

  Separate OBU:
    LoRa sends BIG_CAT, ELEPHANT or ROAD_CLEAR.
    A separate OBU's buzzer still follows its own receiver firmware.
*/

#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>
#include <Preferences.h>
#include "AlertButton.h"
#include <WebServer.h>
#include <math.h>
#include <string.h>

// ================= CONFIGURATION =================

constexpr bool ENABLE_LORA = false;
constexpr bool ENABLE_BUZZER = true;

// Swap HIGH and LOW if your active buzzer module is active-low.
constexpr uint8_t BUZZER_ON = HIGH;
constexpr uint8_t BUZZER_OFF = LOW;
constexpr uint8_t BUZZER_PIN = 27;

constexpr uint8_t OLED_SDA = 21;
constexpr uint8_t OLED_SCL = 22;
constexpr uint8_t OLED_ADDR = 0x3C;

constexpr uint8_t LORA_SS = 5;
constexpr uint8_t LORA_RST = 14;
constexpr uint8_t LORA_DIO0 = 26;

constexpr uint16_t FRAME_SIZE = 1037;
constexpr uint16_t SAMPLE_COUNT = 256;
constexpr uint16_t CRC_OFFSET = 1035;
constexpr uint32_t INPUT_TIMEOUT_MS = 3000;
constexpr uint8_t REQUIRED_WINDOWS = 3;

constexpr uint32_t STARTUP_ANIMATION_MS = 2800;
constexpr uint32_t ANIMAL_BEEP_MS = 2000;

const char *AP_NAME = "V2X-Forest";
const char *AP_PASSWORD = "V2XForest2026";

WebServer server(80);
Adafruit_SSD1306 display(128, 64, &Wire, -1);

// Normally open momentary button: GPIO32 to GND, internal pull-up.
constexpr uint8_t ALERT_BUTTON_PIN=32;
Preferences shieldStore;
uint32_t shieldDevice=0,shieldSequence=0,shieldAt=0;
bool shieldActive=false,shieldAcknowledged=false,shieldStorageOK=false;
AlertButton alertButton;
uint8_t shieldAnimal=0;uint32_t shieldActivationSequence=0;
const char* shieldNotice=nullptr;uint32_t shieldNoticeAt=0;
struct ShieldHistory {uint32_t sequence=0,activation=0;uint8_t animal=0,active=0,pad[2]={};};
ShieldHistory shieldHistory[16];uint8_t shieldHistoryCount=0;
struct ShieldRecord {uint32_t magic=0x57533231,sequence=0,activation=0;uint8_t animal=0,active=0,ack=0,count=0;ShieldHistory history[16];};
void rememberShieldEvent(){
  if(shieldHistoryCount==16){memmove(shieldHistory,shieldHistory+1,sizeof(ShieldHistory)*15);shieldHistoryCount=15;}
  ShieldHistory& e=shieldHistory[shieldHistoryCount++];e.sequence=shieldSequence;e.activation=shieldActivationSequence;e.animal=shieldAnimal;e.active=shieldActive;
}
const char* animalName(){return shieldAnimal==1?"BIG CAT":shieldAnimal==2?"ELEPHANT":"UNSPECIFIED";}
String eventIdFor(uint32_t seq){char id[32];snprintf(id,sizeof(id),"%08lx-%lu",(unsigned long)shieldDevice,(unsigned long)seq);return String(id);}

String shieldEventId(){
  char id[32];snprintf(id,sizeof(id),"%08lx-%lu",(unsigned long)shieldDevice,(unsigned long)shieldSequence);return String(id);
}
void saveShield(){
  ShieldRecord record;record.sequence=shieldSequence;record.activation=shieldActivationSequence;
  record.animal=shieldAnimal;record.active=shieldActive;record.ack=shieldAcknowledged;record.count=shieldHistoryCount;memcpy(record.history,shieldHistory,sizeof(shieldHistory));
  shieldStorageOK=shieldStore.putBytes("state2",&record,sizeof(record))==sizeof(record);
}

// ================= STATE =================

uint8_t wifiFrame[FRAME_SIZE];
uint8_t usbFrame[FRAME_SIZE];

uint16_t usbLength = 0;
uint32_t usbLastByte = 0;

bool oledReady = false;
bool apReady = false;
bool loraReady = false;
bool haveFrame = false;

bool haveConfirmedEvent = false;
bool verifyingPreset = false;
bool oledDirty = true;

uint8_t selectedPreset = 255;
uint8_t activeSource = 0;
uint8_t candidateEvent = 255;
uint8_t matchingWindows = 0;
uint8_t stableEvent = 0;

uint16_t lastSequence = 0;
uint16_t verifiedSequence = 0;
uint32_t lastFrameAt = 0;

float piezoRms = 0;
float micRms = 0;

const char *pendingMessage = nullptr;
uint32_t pendingAt = 0;

bool startupAnimation = false;
uint32_t startupAt = 0;
uint32_t lastAnimationAt = 0;

enum BeepPattern : uint8_t {
  BEEP_NONE,
  BEEP_ANIMAL,
  BEEP_CLEAR
};

void startBeep(BeepPattern pattern);
BeepPattern beepPattern = BEEP_NONE;
uint32_t beepStartedAt = 0;

const char *EVENT_NAMES[] = {
  "ROAD QUIET",
  "BIG CATS CANDIDATE",
  "ELEPHANT CANDIDATE",
  "UNINTERRUPTED NOISE",
  "SHORT NOISE"
};

bool isAnimal(uint8_t event) {
  return event == 1 || event == 2;
}

bool inputFresh() {
  return haveFrame &&
         millis() - lastFrameAt < INPUT_TIMEOUT_MS;
}

// ================= BUZZER =================

void startBeep(BeepPattern pattern) {
  beepPattern = pattern;
  beepStartedAt = millis();
}

void updateBuzzer() {
  if (!ENABLE_BUZZER) return;

  const uint32_t elapsed = millis() - beepStartedAt;
  bool on = false;

  if (beepPattern == BEEP_ANIMAL) {
    on = elapsed < ANIMAL_BEEP_MS;

    if (elapsed >= ANIMAL_BEEP_MS) {
      beepPattern = BEEP_NONE;
    }
  } else if (beepPattern == BEEP_CLEAR) {
    /*
      Three beeps:
        0–200ms:     ON
        200–400ms:   OFF
        400–600ms:   ON
        600–800ms:   OFF
        800–1000ms:  ON
    */
    on = elapsed < 200 ||
         (elapsed >= 400 && elapsed < 600) ||
         (elapsed >= 800 && elapsed < 1000);

    if (elapsed >= 1000) {
      beepPattern = BEEP_NONE;
    }
  }

  digitalWrite(BUZZER_PIN, on ? BUZZER_ON : BUZZER_OFF);
}

void advanceShieldEvent(){
  if(!shieldActive && shieldSequence>=UINT32_MAX-1){shieldDevice=esp_random()|1;shieldStore.putUInt("device",shieldDevice);shieldSequence=0;shieldHistoryCount=0;}
  ++shieldSequence;shieldAt=millis();
}
void serviceShieldButton(){
  const auto action=alertButton.tick(millis(),digitalRead(ALERT_BUTTON_PIN)==LOW,shieldActive);
  if(action==AlertButton::ACTIVATE){
    if(!freshAnimalEligible(haveConfirmedEvent,verifyingPreset,inputFresh(),stableEvent)){
      shieldNotice="NO CONFIRMED ANIMAL";shieldNoticeAt=millis();oledDirty=true;return;
    }
    advanceShieldEvent();shieldActivationSequence=shieldSequence;shieldAnimal=stableEvent;
    shieldActive=true;shieldAcknowledged=false;shieldNotice=nullptr;
    rememberShieldEvent();saveShield();startupAnimation=false;oledDirty=true;startBeep(BEEP_ANIMAL);
    Serial.println("WILDLIFE ALERT: fresh confirmed category latched by triple press");
  }else if(action==AlertButton::CLEAR){
    advanceShieldEvent();shieldActive=false;shieldAcknowledged=true;
    rememberShieldEvent();saveShield();shieldNotice="ANIMAL PASSED";shieldNoticeAt=millis();oledDirty=true;startBeep(BEEP_CLEAR);
    Serial.println("WILDLIFE CLEAR: operator long press; new clear event");
  }
}
String shieldJson(){
  String j="{\"protocol\":\"ELEPHANT-SHIELD-2\",\"device\":"+String(shieldDevice)+",\"sequence\":"+String(shieldSequence);
  j+=",\"eventId\":\""+shieldEventId()+"\",\"alertId\":\""+eventIdFor(shieldActivationSequence)+"\"";
  j+=",\"animal\":"+String(shieldAnimal)+",\"animalCategory\":\""+String(animalName())+"\"";
  j+=",\"active\":"+String(shieldActive?"true":"false")+",\"cleared\":"+String(shieldSequence&&!shieldActive?"true":"false");
  j+=",\"acknowledged\":"+String(shieldAcknowledged?"true":"false");
  j+=",\"storageOK\":"+String(shieldStorageOK?"true":"false")+",\"ageMs\":"+String(millis()-shieldAt);
  j+=",\"oledReady\":"+String(oledReady?"true":"false")+",\"oledState\":\""+String(shieldActive?"ALERT_ACTIVE":shieldNotice?"TEMPORARY_CONFIRMATION":"NORMAL_MONITORING")+"\"}";
  j.remove(j.length()-1);j+=",\"events\":[";
  for(uint8_t i=0;i<shieldHistoryCount;i++){
    const ShieldHistory& e=shieldHistory[i];if(i)j+=",";
    j+="{\"eventId\":\""+eventIdFor(e.sequence)+"\",\"alertId\":\""+eventIdFor(e.activation)+"\",\"sequence\":"+String(e.sequence);
    j+=",\"animalCategory\":\""+String(e.animal==1?"BIG CAT":e.animal==2?"ELEPHANT":"UNSPECIFIED")+"\",\"active\":"+String(e.active?"true":"false")+"}";
  }
  j+="]}";return j;
}
void sendShieldStatus(){server.sendHeader("Cache-Control","no-store");server.send(200,"application/json",shieldJson());}
void shieldAction(bool clear){
  if(clear){server.send(409,"application/json","{\"error\":\"USE_PHYSICAL_TWO_SECOND_HOLD\"}");return;}
  if(server.arg("plain")!=shieldEventId() || !shieldSequence){server.send(409,"application/json","{\"error\":\"EVENT_MISMATCH\"}");return;}
  if(!shieldAcknowledged){shieldAcknowledged=true;saveShield();}sendShieldStatus();
}

// ================= OLED DRAWING HELPERS =================

void centeredText(const char *text, int16_t y, uint8_t size = 1) {
  display.setTextSize(size);
  display.setTextColor(SSD1306_WHITE);
  display.setTextWrap(false);

  int16_t x1, y1;
  uint16_t width, height;
  display.getTextBounds(text, 0, y, &x1, &y1, &width, &height);

  int16_t x = (128 - int16_t(width)) / 2 - x1;
  if (x < 0) x = 0;

  display.setCursor(x, y);
  display.print(text);
}

void drawTree(int16_t x, int16_t ground, uint8_t height) {
  const int16_t top = ground - height;
  const int16_t halfWidth = height / 3;

  display.fillTriangle(
    x, top,
    x - halfWidth, ground - 5,
    x + halfWidth, ground - 5,
    SSD1306_WHITE
  );

  display.fillRect(x - 1, ground - 6, 3, 7, SSD1306_WHITE);
}

void drawDeer(int16_t x, int16_t ground, uint8_t step) {
  display.fillRoundRect(x + 4, ground - 14, 17, 8, 3,
                        SSD1306_WHITE);

  display.drawLine(x + 19, ground - 10,
                   x + 23, ground - 22, SSD1306_WHITE);
  display.drawLine(x + 20, ground - 10,
                   x + 24, ground - 22, SSD1306_WHITE);

  display.fillRoundRect(x + 21, ground - 25, 9, 5, 2,
                        SSD1306_WHITE);

  // Antlers.
  display.drawLine(x + 23, ground - 24,
                   x + 21, ground - 30, SSD1306_WHITE);
  display.drawLine(x + 21, ground - 28,
                   x + 18, ground - 30, SSD1306_WHITE);

  display.drawLine(x + 26, ground - 24,
                   x + 28, ground - 30, SSD1306_WHITE);
  display.drawLine(x + 28, ground - 28,
                   x + 31, ground - 30, SSD1306_WHITE);

  // Alternating legs.
  const int16_t swing = step ? 3 : -3;

  display.drawLine(x + 7, ground - 7,
                   x + 7 + swing, ground, SSD1306_WHITE);
  display.drawLine(x + 17, ground - 7,
                   x + 17 - swing, ground, SSD1306_WHITE);

  display.drawLine(x + 4, ground - 12,
                   x, ground - 17, SSD1306_WHITE);

  display.drawPixel(x + 27, ground - 23, SSD1306_BLACK);
}

void drawCatIcon() {
  display.fillTriangle(5, 27, 8, 14, 18, 25, SSD1306_WHITE);
  display.fillTriangle(23, 25, 33, 14, 36, 27, SSD1306_WHITE);
  display.fillCircle(20, 33, 16, SSD1306_WHITE);

  display.fillTriangle(9, 27, 11, 20, 15, 27, SSD1306_BLACK);
  display.fillTriangle(26, 27, 30, 20, 32, 27, SSD1306_BLACK);

  display.fillCircle(14, 31, 2, SSD1306_BLACK);
  display.fillCircle(26, 31, 2, SSD1306_BLACK);
  display.fillTriangle(17, 37, 23, 37, 20, 41, SSD1306_BLACK);

  display.drawLine(20, 41, 16, 44, SSD1306_BLACK);
  display.drawLine(20, 41, 24, 44, SSD1306_BLACK);

  display.drawLine(5, 36, 13, 38, SSD1306_BLACK);
  display.drawLine(5, 41, 13, 40, SSD1306_BLACK);
  display.drawLine(27, 38, 35, 36, SSD1306_BLACK);
  display.drawLine(27, 40, 35, 41, SSD1306_BLACK);
}

void drawElephantIcon() {
  display.fillRoundRect(3, 24, 26, 19, 5, SSD1306_WHITE);
  display.fillCircle(29, 29, 10, SSD1306_WHITE);

  display.fillRect(6, 40, 6, 10, SSD1306_WHITE);
  display.fillRect(21, 40, 6, 10, SSD1306_WHITE);

  display.fillRoundRect(33, 29, 6, 23, 2, SSD1306_WHITE);
  display.fillRect(28, 47, 8, 5, SSD1306_WHITE);

  display.drawCircle(24, 31, 7, SSD1306_BLACK);
  display.fillCircle(33, 26, 1, SSD1306_BLACK);
  display.drawLine(3, 29, 0, 35, SSD1306_WHITE);
}

void drawLeafIcon() {
  display.drawLine(9, 47, 31, 20, SSD1306_WHITE);
  display.drawLine(10, 47, 32, 20, SSD1306_WHITE);

  display.drawRoundRect(10, 19, 24, 25, 10, SSD1306_WHITE);
  display.drawLine(17, 38, 12, 29, SSD1306_WHITE);
  display.drawLine(22, 32, 18, 22, SSD1306_WHITE);
  display.drawLine(22, 32, 31, 31, SSD1306_WHITE);
  display.drawLine(17, 38, 27, 39, SSD1306_WHITE);
}

void drawJourneyIcon() {
  display.drawLine(7, 49, 17, 17, SSD1306_WHITE);
  display.drawLine(36, 49, 26, 17, SSD1306_WHITE);

  display.drawLine(21, 20, 21, 25, SSD1306_WHITE);
  display.drawLine(21, 30, 21, 36, SSD1306_WHITE);
  display.drawLine(21, 42, 21, 49, SSD1306_WHITE);

  display.drawCircle(33, 19, 5, SSD1306_WHITE);
}

void drawForestIcon() {
  drawTree(10, 48, 24);
  drawTree(23, 48, 34);
  drawTree(35, 48, 21);
  display.drawLine(1, 49, 40, 49, SSD1306_WHITE);
}

// ================= STARTUP ANIMATION =================

void updateStartupAnimation() {
  if (!oledReady || !startupAnimation) return;

  const uint32_t now = millis();
  const uint32_t elapsed = now - startupAt;

  // A confirmed event immediately takes priority over the intro.
  if (elapsed >= STARTUP_ANIMATION_MS || haveConfirmedEvent) {
    startupAnimation = false;
    oledDirty = true;
    return;
  }

  if (now - lastAnimationAt < 100) return;
  lastAnimationAt = now;

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextWrap(false);

  centeredText("WELCOME TO THE WILD", 0);

  drawTree(9, 47, 26);
  drawTree(27, 47, 34);
  drawTree(105, 47, 30);
  drawTree(121, 47, 22);

  display.drawCircle(87, 19, 5, SSD1306_WHITE);
  display.drawLine(0, 48, 127, 48, SSD1306_WHITE);

  // Deer walks gently across the clearing.
  const int16_t deerX = 36 + int32_t(elapsed) * 25 /
                             STARTUP_ANIMATION_MS;
  drawDeer(deerX, 47, (elapsed / 180) % 2);

  centeredText("PROTECT EVERY LIFE", 55);
  display.display();
}

// ================= MAIN OLED =================

void updateOLED() {
  if (!oledReady) return;

  if(shieldActive){
    if(!oledDirty)return;oledDirty=false;
    display.clearDisplay();centeredText(shieldAnimal==2?"ELEPHANT SHIELD":"WILDLIFE ALERT",0);
    display.drawLine(0,10,127,10,SSD1306_WHITE);
    if(shieldAnimal==1)drawCatIcon();else if(shieldAnimal==2)drawElephantIcon();
    display.setTextSize(1);display.setCursor(44,15);display.print(shieldAnimal==1?"BIG CAT":shieldAnimal==2?"ELEPHANT":"LEGACY ALERT");
    display.setCursor(44,25);display.print("ON ROAD");display.setCursor(44,35);display.print("NO HORN");
    display.setCursor(44,45);display.print("KEEP DISTANCE");centeredText("ALERT ACTIVE",56);
    display.display();return;
  }
  if(shieldNotice){
    if(uint32_t(millis()-shieldNoticeAt)<2200){
      if(oledDirty){oledDirty=false;display.clearDisplay();centeredText(shieldNotice,20);centeredText(strcmp(shieldNotice,"ANIMAL PASSED")==0?"ALERT CLEARED":"FRESH ANIMAL REQUIRED",38);display.display();}return;
    }
    shieldNotice=nullptr;oledDirty=true;
  }
  if (startupAnimation) {
    updateStartupAnimation();
    if (startupAnimation) return;
  }

  if (!oledDirty) return;
  oledDirty = false;

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextWrap(false);

  centeredText("V2X WILDLIFE", 0);
  display.drawLine(0, 10, 127, 10, SSD1306_WHITE);

  if (!haveConfirmedEvent) {
    drawTree(10, 48, 25);
    drawTree(119, 48, 25);

    centeredText("FOREST", 18, 2);
    centeredText("GUARDIAN", 35, 1);

    display.drawLine(0, 53, 127, 53, SSD1306_WHITE);
    centeredText(
      verifyingPreset ? "READING FIRST PRESET" : "READY TO WATCH",
      56
    );

    display.display();
    return;
  }

  const char *title;
  const char *subtitle;
  const char *footer;
  uint8_t titleSize = 2;

  switch (stableEvent) {
    case 1:
      drawCatIcon();
      title = "BIG CAT";
      subtitle = "ANIMAL ALERT";
      footer = "SLOW DOWN! NO HORN";
      break;

    case 2:
      drawElephantIcon();
      title = "ELEPHANT";
      titleSize = 1;
      subtitle = "ANIMAL ALERT";
      footer = "SLOW DOWN! NO HORN";
      break;

    case 0:
      drawForestIcon();
      title = "BREATHE";
      titleSize = 1;
      subtitle = "THE WILD";
      footer = "ENJOY THE WILD NATURE!";
      break;

    case 3:
      drawLeafIcon();
      title = "SAVE";
      subtitle = "NATURE";
      footer = "LEAVE ONLY FOOTPRINTS";
      break;

    default:
      drawJourneyIcon();
      title = "TRAVEL";
      titleSize = 1;
      subtitle = "GENTLY";
      footer = "ENJOY YOUR JOURNEY";
      break;
  }

  display.setTextSize(titleSize);
  display.setCursor(44, titleSize == 1 ? 23 : 20);
  display.print(title);

  display.setTextSize(1);
  display.setCursor(44, 40);
  display.print(subtitle);

  display.drawLine(0, 53, 127, 53, SSD1306_WHITE);
  centeredText(footer, 56);

  // One complete framebuffer update; no separate blank frame.
  display.display();
}

// ================= FRAME UTILITIES =================

uint16_t readU16(const uint8_t *data, uint16_t offset) {
  return uint16_t(data[offset]) |
         (uint16_t(data[offset + 1]) << 8);
}

uint16_t crc16(const uint8_t *data, uint16_t length) {
  uint16_t crc = 0xFFFF;

  for (uint16_t i = 0; i < length; i++) {
    crc ^= uint16_t(data[i]) << 8;

    for (uint8_t bit = 0; bit < 8; bit++) {
      crc = (crc & 0x8000)
              ? uint16_t((crc << 1) ^ 0x1021)
              : uint16_t(crc << 1);
    }
  }

  return crc;
}

float calculateRms(const uint8_t *data, uint16_t offset) {
  float mean = 0;
  float sumSquares = 0;

  for (uint16_t i = 0; i < SAMPLE_COUNT; i++) {
    mean += readU16(data, offset + i * 2);
  }

  mean /= SAMPLE_COUNT;

  for (uint16_t i = 0; i < SAMPLE_COUNT; i++) {
    const float difference =
      float(readU16(data, offset + i * 2)) - mean;

    sumSquares += difference * difference;
  }

  return sqrtf(sumSquares / SAMPLE_COUNT);
}

uint8_t classify(float piezo, float mic) {
  // Original classifier threshold order retained.
  if (piezo < 20.0f && mic < 15.0f) return 0;
  if (piezo > 118.0f) return 2;
  if (piezo > 85.0f) return 3;
  if (mic > 45.0f) return 1;
  return 4;
}

const char *messageForEvent(uint8_t event) {
  if (event == 1) return "BIG_CAT";
  if (event == 2) return "ELEPHANT";

  // Requested demonstration behavior for non-animal presets.
  return "ROAD_CLEAR";
}

// ================= EVENT TRANSITIONS =================

void confirmEvent(uint8_t event, uint32_t now) {
  const bool previouslyAnimal =
    haveConfirmedEvent && isAnimal(stableEvent);

  const bool eventChanged =
    !haveConfirmedEvent || stableEvent != event;

  if (eventChanged && !shieldActive) {
    if (isAnimal(event)) {
      // Once when entering a new confirmed animal event.
      startBeep(BEEP_ANIMAL);
    } else if (previouslyAnimal) {
      // Once when leaving an animal event.
      startBeep(BEEP_CLEAR);
    }
    // Other non-animal transitions do not start a sound.
  }

  stableEvent = event;
  haveConfirmedEvent = true;
  verifyingPreset = false;
  verifiedSequence = lastSequence;
  matchingWindows = 0;
  oledDirty = true;

  pendingMessage = messageForEvent(stableEvent);
  pendingAt = now;

  Serial.printf(
    "CONFIRMED AND HELD: %s | preset=%u | sequence=%u\n",
    EVENT_NAMES[stableEvent],
    selectedPreset,
    lastSequence
  );
}

const char *processFrame(const uint8_t *data, uint8_t source) {
  if (memcmp(data, "VFZ1", 4) != 0) return "FRAME_HEADER";
  if (data[6] > 4) return "SCENARIO_RANGE";
  if (readU16(data, 7) != 500) return "SAMPLE_RATE";
  if (readU16(data, 9) != SAMPLE_COUNT) return "SAMPLE_COUNT";

  if (crc16(data, CRC_OFFSET) != readU16(data, CRC_OFFSET)) {
    return "FRAME_CRC";
  }

  for (uint16_t offset = 11; offset < CRC_OFFSET; offset += 2) {
    if (readU16(data, offset) > 4095) return "ADC_RANGE";
  }

  const uint32_t now = millis();
  const bool fresh = inputFresh();
  const uint16_t sequence = readU16(data, 4);
  const uint8_t preset = data[6];

  if (fresh && source != activeSource) {
    return "OTHER_INPUT_ACTIVE";
  }

  if (fresh && int16_t(sequence - lastSequence) <= 0) {
    return "DUPLICATE_OR_OLD_FRAME";
  }

  if (!fresh) {
    matchingWindows = 0;
    if (verifyingPreset) candidateEvent = 255;
  }

  activeSource = source;
  haveFrame = true;
  lastSequence = sequence;
  lastFrameAt = now;

  piezoRms = calculateRms(data, 11);
  micRms = calculateRms(data, 523);

  if (preset != selectedPreset) {
    selectedPreset = preset;
    verifyingPreset = true;
    matchingWindows = 0;
    candidateEvent = 255;
    pendingMessage = nullptr;

    // Retain the previous confirmed screen during verification.
    if (!haveConfirmedEvent) oledDirty = true;
  }

  if (verifyingPreset) {
    const uint8_t candidate = classify(piezoRms, micRms);

    if (candidate == candidateEvent) {
      if (matchingWindows < REQUIRED_WINDOWS) matchingWindows++;
    } else {
      candidateEvent = candidate;
      matchingWindows = 1;
    }

    if (matchingWindows >= REQUIRED_WINDOWS) {
      confirmEvent(candidate, now);
    }
  } else if (haveConfirmedEvent) {
    /*
      Same selected preset:
      retain its confirmed event instead of alternating between
      CHECKING and the animal name due to window fluctuations.
      No beep or OLED redraw is triggered by these refreshes.
    */
    if (++matchingWindows >= REQUIRED_WINDOWS) {
      matchingWindows = 0;
      verifiedSequence = lastSequence;

      pendingMessage = messageForEvent(stableEvent);
      pendingAt = now;
    }
  }

  return nullptr;
}

// ================= LORA =================

void serviceLoRa() {
  if (!loraReady || pendingMessage == nullptr) return;

  if (millis() - pendingAt >= INPUT_TIMEOUT_MS) {
    pendingMessage = nullptr;
    return;
  }

  // Public API: checks whether the previous TX is still busy.
  if (!LoRa.beginPacket()) return;

  const char *message = pendingMessage;
  LoRa.print(message);

  if (LoRa.endPacket(true)) {
    Serial.print("LoRa TX started: ");
    Serial.println(message);
    pendingMessage = nullptr;
  }

  // TX start is not a delivery acknowledgement from the remote OBU.
}

// ================= DASHBOARD HTTP =================

void sendError(int code, const char *message) {
  server.sendHeader("Cache-Control", "no-store");

  String json = "{\"protocol\":\"VFZ1-WIFI-1\",\"error\":\"";
  json += message;
  json += "\"}";

  server.send(code, "application/json", json);
}

void sendStatus() {
  /*
    Hold the event text for display continuity.
    A stale connection or pending preset change is not marked
    as fresh verification.
  */
  const bool freshVerification =
    haveConfirmedEvent && !verifyingPreset && inputFresh();

  String json;
  json.reserve(520);

  json = "{\"protocol\":\"VFZ1-WIFI-1\",";
  json += "\"source\":\"SYNTHETIC_VFZ1\",";
  json += "\"sequence\":";
  json += lastSequence;
  json += ",\"verifiedSequence\":";
  json += verifiedSequence;
  json += ",\"verified\":";
  json += freshVerification ? "true" : "false";
  json += ",\"event\":\"";

  if (haveConfirmedEvent) {
    json += EVENT_NAMES[stableEvent];
  } else {
    json += verifyingPreset ? "VERIFYING FIRST PRESET" : "FSU READY";
  }

  json += "\",\"piezoRms\":";
  json += String(piezoRms, 2);
  json += ",\"micRms\":";
  json += String(micRms, 2);
  json += ",\"matchingWindows\":";
  json += matchingWindows;
  json += ",\"loraReady\":";
  json += loraReady ? "true" : "false";
  json += ",\"oledReady\":";
  json += oledReady ? "true" : "false";
  json += ",\"inputFresh\":";
  json += inputFresh() ? "true" : "false";
  json += ",\"displayHeld\":";
  json += haveConfirmedEvent ? "true" : "false";
  json += ",\"changingPreset\":";
  json += verifyingPreset ? "true" : "false";
  json += ",\"shield\":";json += shieldJson();
  json += "}";

  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", json);
}

int hexDigit(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

void receiveWiFiFrame() {
  const String body = server.arg("plain");

  if (body.length() != FRAME_SIZE * 2U) {
    sendError(400, "FRAME_LENGTH");
    return;
  }

  for (uint16_t i = 0; i < FRAME_SIZE; i++) {
    const int high = hexDigit(body[i * 2]);
    const int low = hexDigit(body[i * 2 + 1]);

    if (high < 0 || low < 0) {
      sendError(400, "HEX_ENCODING");
      return;
    }

    wifiFrame[i] = uint8_t((high << 4) | low);
  }

  const char *error = processFrame(wifiFrame, 1);

  if (error) {
    const bool conflict =
      strcmp(error, "OTHER_INPUT_ACTIVE") == 0 ||
      strcmp(error, "DUPLICATE_OR_OLD_FRAME") == 0;

    sendError(conflict ? 409 : 400, error);
    return;
  }

  sendStatus();
}

// ================= USB INPUT =================

void readUSBFrames() {
  if (usbLength && millis() - usbLastByte > 1000) {
    usbLength = 0;
  }

  uint16_t budget = 512;

  while (budget-- && Serial.available()) {
    usbLastByte = millis();
    usbFrame[usbLength++] = uint8_t(Serial.read());

    while (usbLength >= 4 &&
           memcmp(usbFrame, "VFZ1", 4) != 0) {
      usbLength--;
      memmove(usbFrame, usbFrame + 1, usbLength);
    }

    if (usbLength == FRAME_SIZE) {
      if (crc16(usbFrame, CRC_OFFSET) ==
          readU16(usbFrame, CRC_OFFSET)) {
        const char *error = processFrame(usbFrame, 2);

        if (error) {
          Serial.print("USB frame rejected: ");
          Serial.println(error);
        }

        usbLength = 0;
      } else {
        memmove(usbFrame, usbFrame + 1, FRAME_SIZE - 1);
        usbLength = FRAME_SIZE - 1;
      }
    }
  }
}

// ================= SETUP =================

void setup() {
  Serial.setRxBufferSize(4096);
  Serial.begin(115200);
  delay(300);

  Serial.println("\nV2X WILDLIFE FSU");
  pinMode(ALERT_BUTTON_PIN, INPUT_PULLUP);
  shieldStorageOK=shieldStore.begin("elephantshield",false);
  shieldDevice=shieldStore.getUInt("device",0);
  if(!shieldDevice){shieldDevice=esp_random()|1;shieldStore.putUInt("device",shieldDevice);}
  ShieldRecord record;
  if(shieldStore.getBytesLength("state2")==sizeof(record)){
    shieldStore.getBytes("state2",&record,sizeof(record));
    if(record.magic==0x57533231 && record.animal<=2 && record.active<=1 && record.count<=16){
      shieldSequence=record.sequence;shieldActivationSequence=record.activation;shieldAnimal=record.animal;
      shieldActive=record.active;shieldAcknowledged=record.ack;shieldHistoryCount=record.count;memcpy(shieldHistory,record.history,sizeof(shieldHistory));
    }else shieldStorageOK=false;
  }else{
    // Preserve an older unclassified manual latch locally; never invent its species.
    uint64_t old=shieldStore.getULong64("latch",0);shieldSequence=old>>2;
    shieldActivationSequence=shieldSequence;shieldActive=old&1;shieldAnimal=0;
  }
  shieldAt=millis();

  if (ENABLE_BUZZER) {
    pinMode(BUZZER_PIN, OUTPUT);
    digitalWrite(BUZZER_PIN, BUZZER_OFF);
  }

  Wire.begin(OLED_SDA, OLED_SCL);
  Wire.setTimeOut(50);

  Wire.beginTransmission(OLED_ADDR);
  const bool oledResponds = Wire.endTransmission() == 0;

  if (oledResponds) {
    oledReady = display.begin(
      SSD1306_SWITCHCAPVCC,
      OLED_ADDR,
      false,
      false
    );
  }

  Serial.println(oledReady ? "OLED ready" : "OLED not detected");

  if (oledReady) {
    display.clearDisplay();
    centeredText("WILDLIFE", 18, 2);
    centeredText("FOREST GUARDIAN", 43);
    display.display();
  }

  if (ENABLE_LORA) {
    SPI.begin(18, 19, 23, LORA_SS);
    LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);
    loraReady = LoRa.begin(433E6);

    if (loraReady) {
      LoRa.setSpreadingFactor(7);
      LoRa.setSignalBandwidth(125E3);
      LoRa.setCodingRate4(5);
      LoRa.setPreambleLength(8);
      LoRa.setSyncWord(0x52);
      LoRa.enableCrc();
      LoRa.setTxPower(17, PA_OUTPUT_PA_BOOST_PIN);

      Serial.println("LoRa ready");
    } else {
      Serial.println("LoRa unavailable; Wi-Fi/OLED remain available.");
    }
  }

  WiFi.mode(WIFI_AP);
  apReady = WiFi.softAP(AP_NAME, AP_PASSWORD, 1);

  if (apReady) {
    server.on("/shield/status",HTTP_GET,sendShieldStatus);
    server.on("/shield/ack",HTTP_POST,[](){shieldAction(false);});
    server.on("/shield/clear",HTTP_POST,[](){shieldAction(true);});
    server.on("/status", HTTP_GET, sendStatus);
    server.on("/frame", HTTP_POST, receiveWiFiFrame);
    server.onNotFound([]() {
      sendError(404, "NOT_FOUND");
    });

    server.begin();

    Serial.print("Wi-Fi: ");
    Serial.println(AP_NAME);
    Serial.print("FSU IP: ");
    Serial.println(WiFi.softAPIP());
  } else {
    Serial.println("Wi-Fi AP failed; USB input remains available.");
  }

  startupAnimation = oledReady;
  startupAt = millis();
  lastAnimationAt = startupAt - 100;

  Serial.println("Select a dashboard preset and enable live sending.");
  Serial.println("Animal: 5-second beep. Animal clear: 3 short beeps.");
}

// ================= LOOP =================

void loop() {
  serviceShieldButton();
  if (apReady) server.handleClient();

  readUSBFrames();
  serviceLoRa();
  updateBuzzer();
  updateOLED();

  delay(1);
}