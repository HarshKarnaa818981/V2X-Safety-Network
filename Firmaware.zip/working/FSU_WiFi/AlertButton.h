#pragma once
#include <stdint.h>
// Shared by the FSU and native regression tests. uint32 subtraction is wrap-safe.
class AlertButton {
 bool raw=false,stable=false,consumed=false;uint32_t edgeAt=0,downAt=0,firstAt=0;uint8_t clicks=0;
public:
 enum Action {NONE,ACTIVATE,CLEAR};
 Action tick(uint32_t now,bool down,bool active){
  if(clicks&&uint32_t(now-firstAt)>2500)clicks=0;
  if(down!=raw){raw=down;edgeAt=now;}
  if(raw!=stable&&uint32_t(now-edgeAt)>=40){
   stable=raw;
   if(stable){downAt=edgeAt;consumed=false;}
   else if(!consumed){
    const uint32_t duration=edgeAt-downAt;
    if(duration>=2000){clicks=0;consumed=true;return active?CLEAR:NONE;}
    if(active){clicks=0;return NONE;}
    if(!clicks)firstAt=downAt;
    if(++clicks==3){clicks=0;return ACTIVATE;}
   }
  }
  if(stable&&raw&&!consumed&&uint32_t(now-downAt)>=2000){consumed=true;clicks=0;return active?CLEAR:NONE;}
  return NONE;
 }
};

inline bool freshAnimalEligible(bool confirmed,bool changing,bool fresh,uint8_t event){return confirmed&&!changing&&fresh&&(event==1||event==2);}
