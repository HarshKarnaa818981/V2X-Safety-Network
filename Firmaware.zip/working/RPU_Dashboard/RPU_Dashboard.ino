// V2X-DASH-4: independent wildlife, serial protocol 4, accepted-state telemetry.
// Eight-scenario OLED edition; actual-link fallback; synchronized presentation.
// RPU_BendOnly: standalone LoRa breadboard demonstration.
#define ID 0
#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>
#include <esp_random.h>
#include <math.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <cstring>
namespace Demo {
// TABLETOP SIMULATION. Positions in virtual mm, never RF-derived distance.
constexpr uint32_t MAGIC=0x56525434, LIVE=3000, LEASE=2000, SCENE_COUNTDOWN_MS=1200;
constexpr uint16_t BEND_GATE=200, BEND_IN=300, BEND_OUT=500;
constexpr uint16_t FOREST_GATE=700, FOREST_IN=800, FOREST_OUT=1000, FINISH=1100;
constexpr uint8_t CASES=8;
enum Phase:uint8_t {RESET,COUNT,RUN,FAULT,PAUSED}; // PAUSED is controller-local; never transmitted in the V3 packet.
enum Reason:uint8_t {SYNC,NORMAL,APPROACH,QUEUE,UPHILL,EMERGENCY,FIRST,BOTH,
  WILDLIFE,SENSOR,FSU_LOST,LINK,MPU_CHECK,RESTART,COMPLETE};
enum Type:uint8_t {CAR,TRUCK,POLICE,AMBULANCE,FIRE,BIKE,EMPTY};
const char* types[]={"CAR","LOADED TRUCK","POLICE","AMBULANCE","FIRE TRUCK","BIKE","EMPTY TRUCK"};
const char* reasons[]={"SYNC","NORMAL","APPROACH","BEND BUSY","UPHILL LOAD","EMERGENCY",
  "FIRST COME","BOTH PASS","WILDLIFE","SENSOR","FSU LOST","LINK LOST",
  "CHECK MPU","RESET DEMO","FINISHED"};
const char* scenes[]={"NORMAL TWO-WAY TRAFFIC","EMPTY TRUCK VS CAR","LOADED TRUCK VS CAR",
  "TWO LOADED TRUCKS","AMBULANCE VS CAR","EMERGENCY CONFLICT","FOREST & WILDLIFE",
  "LORA FAILURE AND WI-FI RECOVERY"};
constexpr uint32_t DISPLAY_STAGE_MS=5000, SCENARIO_MS=15000;
constexpr uint16_t ARRIVAL_TIE_MS=250;
enum DisplayMotion:uint8_t {DISPLAY_WAIT,DISPLAY_GO,DISPLAY_SLOW};
uint32_t ms(); bool newer(uint32_t a,uint32_t b); uint32_t newBoot();
Type vehicle(uint8_t scene,uint8_t id); bool urgent(uint8_t scene,uint8_t id);
const char* zone(uint16_t pos);
uint32_t ms(){return (uint32_t)millis();}
bool newer(uint32_t a,uint32_t b){return (int32_t)(a-b)>0;}
uint32_t newBoot(){uint32_t n=esp_random();return n?n:1;}
Type vehicle(uint8_t s,uint8_t id){
  const Type v[CASES][2]={{CAR,CAR},{EMPTY,CAR},{TRUCK,CAR},{TRUCK,TRUCK},
    {AMBULANCE,CAR},{AMBULANCE,FIRE},{CAR,CAR},{CAR,CAR}};
  return s<CASES && id>=1 && id<=2?v[s][id-1]:CAR;
}
bool urgent(uint8_t s,uint8_t id){return (s==4 && id==1) || s==5;}
const char* zone(uint16_t x){
  return x<BEND_GATE?"ROAD":x<BEND_IN?"BEND APPROACH":x<BEND_OUT?"BEND":x<FOREST_GATE?"ROAD":x<FOREST_IN?"FOREST APPROACH":x<FOREST_OUT?"FOREST":"EXIT";
}
struct Packet {
  uint32_t magic=MAGIC,hub=0,seq=0,boot=0,sampleSeq=0;
  uint16_t round=0,pos=0,limit=0,ttl=0,age=65535,p2p=0,rms10=0,hz10=0;
  int16_t pitch=0,roll=0;
  uint8_t from=0,to=0,kind=0,phase=RESET,scene=0,reason=SYNC,mpu=0,wildlife=0;
  // V2 extension, same on all four nodes. Elapsed time is RPU-owned.
  uint32_t sceneElapsed=0;
  uint8_t stage=0,nextScene=1,ownType=CAR,motion=DISPLAY_WAIT;
  uint32_t shieldDevice=0,shieldSeq=0;
  uint8_t shieldActive=0,shieldAnimal=0,shieldReserved[2]={};
  bool valid()const{return shieldActive<=1 && shieldAnimal<=2 && stage<=3 && nextScene<CASES && ownType<=EMPTY && motion<=DISPLAY_SLOW && magic==MAGIC && hub && seq && from<=3 && to<=3 && from!=to &&
    kind<=1 && phase<=FAULT && scene<CASES && reason<=COMPLETE && pos<=FINISH &&
    limit<=FINISH && ttl<=6000 && mpu<=3 && wildlife<=2;}
};
static_assert(sizeof(Packet)==68,"V4 Packet layout mismatch");
class Radio {
  static volatile bool txDone;
  static void onSent();
  bool txHooked=false;
 public:
  bool ready=false,busy=false;uint32_t started=0,retry=0;
  uint32_t txOK=0,txTimeout=0,rxRaw=0,rxBad=0,rxAddressed=0;
  uint8_t versionRegister(){
    SPI.beginTransaction(SPISettings(1000000,MSBFIRST,SPI_MODE0));
    digitalWrite(5,LOW);SPI.transfer(0x42);uint8_t v=SPI.transfer(0);
    digitalWrite(5,HIGH);SPI.endTransaction();return v;
  }
  void diagnostics(){
    Serial.printf("LORA DIAG node=%u init=%u busy=%u tx-done=%lu tx-timeout=%lu rx-raw=%lu rx-rejected=%lu rx-addressed=%lu\n",
      ID,ready,busy,(unsigned long)txOK,(unsigned long)txTimeout,
      (unsigned long)rxRaw,(unsigned long)rxBad,(unsigned long)rxAddressed);
  }
  void detachTx(){if(txHooked){LoRa.onTxDone(nullptr);txHooked=false;}}
  void start(){
    retry=ms();busy=false;LoRa.setPins(5,14,26);
    detachTx();txDone=false;
    // Explicit original wiring; slower SPI improves breadboard signal margin.
    LoRa.setSPI(SPI);LoRa.setSPIFrequency(1000000);
    ready=LoRa.begin(433E6);
    uint8_t version=versionRegister();
    Serial.printf("LORA CHIP node=%u RegVersion=0x%02X expected=0x12\n",ID,version);
    if(!ready){
      Serial.println("LORA INIT FAILED: SX127x version check failed; retry in 3 sec. WIFI STANDBY.");
      Serial.println("Check 3V3/GND, CS5 RST14 SCK18 MISO19 MOSI23 and module. Antenna/peer absence does NOT cause the SPI version check to fail.");
      return;
    }
    LoRa.setSpreadingFactor(7);LoRa.setSignalBandwidth(125E3);LoRa.setCodingRate4(5);
    LoRa.setPreambleLength(8);LoRa.setSyncWord(0x52);LoRa.enableCrc();LoRa.setTxPower(2);
    LoRa.receive();Serial.println("LORA READY 433MHz SF7 BW125");
  }
  void begin(){SPI.begin(18,19,23,5);start();}
  void tick(){
    if(!ready && ms()-retry>=3000)start();
    if(busy){
      if(txDone){
        ++txOK;
        // Reception is polled: detach the ISR before mapping DIO0 to RX_DONE.
        detachTx();txDone=false;busy=false;LoRa.receive();
      }else if(ms()-started>=350){
        ++txTimeout;
        detachTx();LoRa.idle();txDone=false;
        ready=busy=false;retry=ms();
        Serial.println("LORA TX TIMEOUT: check DIO0 -> GPIO26; retry in 3 sec");
      }
    }
  }
  bool send(const Packet& p){
    if(!ready || busy || !LoRa.beginPacket())return false;
    if(LoRa.write((const uint8_t*)&p,sizeof(p))!=sizeof(p)){
      LoRa.receive();return false;
    }
    txDone=false;LoRa.onTxDone(onSent);txHooked=true;
    busy=true;started=ms();
    if(!LoRa.endPacket(true)){
      detachTx();txDone=false;busy=false;LoRa.receive();return false;
    }
    return true;
  }
  bool read(Packet& p){
    if(!ready || busy)return false;
    int n=LoRa.parsePacket();if(!n)return false;++rxRaw;
    bool ok=n==(int)sizeof(p);
    if(ok){uint8_t* b=(uint8_t*)&p;for(size_t i=0;i<sizeof(p);i++)b[i]=LoRa.read();}
    while(LoRa.available()){LoRa.read();}
    LoRa.receive();
    if(!ok || !p.valid()){++rxBad;return false;}
    if(p.to!=ID)return false;
    ++rxAddressed;return true;
  }
};
volatile bool Radio::txDone=false;
// Out-of-class definition avoids Xtensa inline IRAM literal relocation errors.
void IRAM_ATTR Radio::onSent(){txDone=true;}
// Added transport only. Radio changes above only guard interrupt detachment.
// One four-node demo set: fixed locally administered MACs, channel and demo keys.
// Change the MAC prefix and BOTH keys consistently for another nearby demo set.
class FailoverRadio {
  static constexpr uint32_t TAG=0x56465831;
  static constexpr uint8_t CHANNEL=6, NODES=4;
  struct Frame {
    uint32_t tag=TAG;
    uint8_t version=5,from=ID,to=0,control=0;
    Packet packet;
  };
  struct Received {Frame frame;uint32_t at;};
  static QueueHandle_t inbox;
  static void receiveWiFi(const esp_now_recv_info_t* info,const uint8_t* bytes,int len);
  Radio lora;
  QueueHandle_t dataQueue=nullptr;
  bool wifiMode=false,wifiReady=false,espNowStarted=false;
  bool testLoss=false;
  public: void injectPrimaryLoss(bool enabled=true){testLoss=enabled;}
  private:
  bool restoring=false;uint32_t restoreAt=0;
  bool postDemo=false; // Actual primary-link failure latch; no scenario-triggered fault.
  Packet lastPoll[4]; uint32_t lastRx[4]={},pollStarted[4]={},startedAt=0; bool polled[4]={};
  bool wifiSeen[NODES]={};
  uint32_t wifiAt[NODES]={};
  uint32_t knownHub=0,knownSeq=0;uint16_t knownRound=0;uint8_t knownScene=0;
  Packet completion;
  uint32_t wifiRetry=0,controlAt=0,statusAt=0,sendErrors=0,activatedAt=0;
  uint8_t controlTarget=1;
  const char* cause="NONE";
  static void mac(uint8_t node,uint8_t* out){
    const uint8_t prefix[6]={0x02,0x56,0x32,0x42,0x01,0};
    memcpy(out,prefix,6);out[5]=node;
  }
  bool setupWiFi(){
    wifiRetry=ms();wifiReady=false;
    if(espNowStarted){esp_now_deinit();espNowStarted=false;}
    if(!inbox)inbox=xQueueCreate(12,sizeof(Received));
    if(!dataQueue)dataQueue=xQueueCreate(8,sizeof(Received));
    if(!inbox || !dataQueue){Serial.println("WIFI BACKUP ERROR: queue allocation");return false;}
    WiFi.persistent(false);WiFi.setAutoReconnect(false);
    if(!WiFi.mode(WIFI_STA)){Serial.println("WIFI BACKUP ERROR: STA start");return false;}
    // Stop the interface before setting its locally administered demo MAC.
    esp_err_t e=esp_wifi_stop();
    uint8_t own[6];mac(ID,own);
    if(e==ESP_OK)e=esp_wifi_set_mac(WIFI_IF_STA,own);
    if(e==ESP_OK)e=esp_wifi_start();
    if(e==ESP_OK)e=esp_wifi_set_ps(WIFI_PS_NONE);
    if(e==ESP_OK)e=esp_wifi_set_channel(CHANNEL,WIFI_SECOND_CHAN_NONE);
    if(e==ESP_OK)e=esp_now_init();
    if(e!=ESP_OK){Serial.printf("WIFI BACKUP INIT ERROR=%d; retry in 3 sec\n",(int)e);return false;}
    espNowStarted=true;
    const uint8_t pmk[16]={0x37,0x2a,0x91,0xb5,0x18,0x43,0xf0,0x67,0xd2,0x0e,0x84,0x59,0xaa,0x6c,0x13,0xe8};
    const uint8_t lmk[16]={0x5b,0x08,0xc6,0x42,0xef,0x93,0x71,0x2d,0xa0,0x3e,0x64,0x19,0xd7,0x85,0xbc,0x20};
    e=esp_now_set_pmk(pmk);
    for(uint8_t node=0;node<NODES && e==ESP_OK;node++){
      if(node==ID || (ID!=0 && node!=0))continue;
      esp_now_peer_info_t peer={};mac(node,peer.peer_addr);
      peer.channel=CHANNEL;peer.ifidx=WIFI_IF_STA;peer.encrypt=true;
      memcpy(peer.lmk,lmk,16);e=esp_now_add_peer(&peer);
    }
    if(e==ESP_OK)e=esp_now_register_recv_cb(receiveWiFi);
    if(e!=ESP_OK){Serial.printf("WIFI BACKUP PEER ERROR=%d; retry in 3 sec\n",(int)e);return false;}
    wifiReady=true;
    Serial.printf("WIFI STANDBY READY: ESP-NOW channel %u node %u (backup waits for actual primary-link failure)\n",CHANNEL,ID);
    return true;
  }
 public:
  bool sendFrame(const Frame& f){
    if(!wifiReady)return false;
    uint8_t destination[6];mac(f.to,destination);
    esp_err_t e=esp_now_send(destination,(const uint8_t*)&f,sizeof(f));
    if(e!=ESP_OK)++sendErrors;
    return e==ESP_OK; // Queued only; existing controller reply checks prove delivery.
  }
  void activate(const char* why){
    if(wifiMode)return;restoring=false;
    wifiMode=true;cause=why;activatedAt=ms();
    lora.detachTx();
    LoRa.sleep(); // Discontinue this node's LoRa; do not call its retry loop again.
    lora.ready=false;lora.busy=false;busy=false;ready=wifiReady;
    controlAt=ms()-150;
    Serial.printf("LORA DISCONNECTED: %s | WIFI FAILOVER %s\n",cause,
      wifiReady?"ACTIVE; waiting for valid peer traffic":"PENDING: WIFI INIT ERROR");
  }
  void markFinal(){
    if(postDemo)return;
    postDemo=true;
    activate("PRIMARY LINK TIMEOUT");
  }
 public:
  bool ready=false,busy=false;
  bool usingWiFi()const{return wifiMode;}
  bool transitionVisible()const{return postDemo && ms()-activatedAt<3000;}
  bool backupReady()const{return wifiReady;}
  bool peerWiFi(uint8_t node)const{return node<NODES && wifiMode && wifiReady &&
    wifiSeen[node] && ms()-wifiAt[node]<LIVE;}
  bool loraReady()const{return lora.ready && !wifiMode && !restoring;}
  bool restoringPrimary()const{return restoring;}
  void restorePrimary(){if(!wifiMode)return;wifiMode=false;postDemo=false;restoring=true;restoreAt=ms();startedAt=ms();memset(lastRx,0,sizeof(lastRx));lora.begin();ready=lora.ready;busy=false;controlAt=ms()-150;}
  void diagnostics(){if(!wifiMode)lora.diagnostics();}
  bool wifiConfirmed()const{
    if(!wifiMode || !wifiReady)return false;
    if(ID==0){
      for(uint8_t node=1;node<NODES;node++){
        // OBU nodes are always supervised. The FSU is included only after
        // the operator activates the final FSU stage and the RPU polls it.
        if(!polled[node])continue;
        if(!wifiSeen[node] || ms()-wifiAt[node]>=LIVE)return false;
      }
      return true;
    }
    return wifiSeen[0]&&ms()-wifiAt[0]<LIVE;
  }
  const char* badge()const{return !wifiReady?"WIFI ERR":wifiConfirmed()?"WIFI":"WIFI...";}
  void begin(){
    // Bring up the primary radio before preparing the backup interface.
    Serial.printf("FIRMWARE: FINAL-REPLAY-1 node=%u\n",ID);
    lora.begin();setupWiFi();startedAt=ms();
    ready=lora.ready;busy=lora.busy;
    Serial.println("LORA PRIMARY; automatic ESP-NOW backup only on actual primary reply timeout");
  }
  // Call only AFTER the existing Controller has accepted a matching packet.
  void accepted(const Packet& p){
    if(p.from>=NODES)return;
    lastRx[p.from]=ms();
    if(ID!=0 && !wifiMode && p.from==0){
      knownHub=p.hub;knownSeq=p.seq;knownRound=p.round;knownScene=p.scene;
    }
    if(wifiMode){
      bool first=!wifiSeen[p.from];wifiSeen[p.from]=true;wifiAt[p.from]=ms();
      if(first)Serial.printf("WIFI RX CONFIRMED: node %u; original packet checks passed\n",p.from);
    }
  }
  bool postDemoActive()const{return postDemo;}
  void testFailover(){Serial.println("No synthetic failure: backup is selected by actual primary-link loss.");}
  void tick(){
    if(!wifiReady && ms()-wifiRetry>=3000)setupWiFi();
    Received rx;
    while(inbox && xQueueReceive(inbox,&rx,0)==pdTRUE){
      if(ms()-rx.at>250)continue;
      if(rx.frame.control==3){
        const Packet& event=rx.frame.packet;
        if(ID!=0 && wifiMode && (!knownHub || event.hub==knownHub))restorePrimary();
      }else if(rx.frame.control==2){
        const Packet& event=rx.frame.packet;
        // Encrypted RPU control; preserve the current round and virtual position.
        if(ID!=0 && !wifiMode && (!knownHub || (event.hub==knownHub &&
           (event.seq==knownSeq || newer(event.seq,knownSeq)))))markFinal();
      }else if(!rx.frame.control && wifiMode){
        if(dataQueue)xQueueSend(dataQueue,&rx,0);
      }
    }
    if(restoring){
      const bool confirmed=ID==0?(lastRx[1]&&lastRx[2]&&ms()-lastRx[1]<LIVE&&ms()-lastRx[2]<LIVE):lastRx[0]!=0;
      if(confirmed){restoring=false;Serial.println("LORA RESTORED: matching primary poll/reply handshake confirmed");}
      else if(ms()-restoreAt>=8000){postDemo=true;activate("PRIMARY RESTORE HANDSHAKE TIMEOUT");}
      if(ID==0 && restoring && ms()-controlAt>=150){
        for(uint8_t n=1;n<=2;n++)if(polled[n]){Frame f;f.control=3;f.to=n;f.packet=lastPoll[n];sendFrame(f);}controlAt=ms();
      }
    }
    if(!wifiMode)lora.tick();
    if(ID==0 && !wifiMode && ms()-startedAt>=6000){
      // No switch is caused by entering S8, MPU calibration or a wildlife hold.
      for(uint8_t n=1;n<NODES;n++){
        if(!polled[n])continue;
        uint32_t sinceRx=lastRx[n]?ms()-lastRx[n]:ms()-startedAt;
        if(sinceRx>=6000 && ms()-pollStarted[n]>=6000){markFinal();break;}
      }
    }
    if(ID==0 && wifiMode && wifiReady && ms()-controlAt>=150){
      if(polled[controlTarget]){
        Frame f;f.control=2;f.to=controlTarget;f.packet=lastPoll[controlTarget];sendFrame(f);
      }
      controlAt=ms();controlTarget=controlTarget+1<NODES?controlTarget+1:1;
    }
    ready=wifiMode?wifiReady:lora.ready;busy=wifiMode?false:lora.busy;
    if(wifiMode && ms()-statusAt>=2000){
      statusAt=ms();Serial.printf("LINK STATUS: LORA OFF | WIFI %s | fault=%s | queue-errors=%lu\n",
        !wifiReady?"INIT ERROR":wifiConfirmed()?"ACTIVE / RX CONFIRMED":"ACTIVE / WAITING FOR PEER",
        cause,(unsigned long)sendErrors);
    }
  }
  bool send(const Packet& p){
    if(ID==0 && p.to<NODES){
      if(!polled[p.to] || lastPoll[p.to].round!=p.round)pollStarted[p.to]=ms();
      lastPoll[p.to]=p;polled[p.to]=true;
    }
    if(!wifiMode && testLoss)return true; // Controlled primary loss; timeout still selects backup.
    if(!wifiMode){bool ok=lora.send(p);ready=lora.ready;busy=lora.busy;return ok;}
    if(p.to>=NODES || p.from!=ID)return false;
    Frame f;f.to=p.to;f.packet=p;return sendFrame(f);
  }
  bool read(Packet& p){
    if(!wifiMode){if(testLoss){Packet discard;while(lora.read(discard)){}return false;}return lora.read(p);}
    Received rx;
    while(dataQueue && xQueueReceive(dataQueue,&rx,0)==pdTRUE){
      if(ms()-rx.at>250)continue;
      p=rx.frame.packet;return true;
    }
    return false;
  }
};
QueueHandle_t FailoverRadio::inbox=nullptr;
void FailoverRadio::receiveWiFi(const esp_now_recv_info_t* info,const uint8_t* bytes,int len){
  if(!info || !info->src_addr || !info->des_addr || !bytes)return;
  if(!inbox || len!=(int)sizeof(Frame))return;
  Received rx;memcpy(&rx.frame,bytes,sizeof(Frame));rx.at=ms();
  const Frame& f=rx.frame;
  if(f.tag!=TAG || f.version!=5 || f.from>=NODES || f.from==ID || f.to!=ID || f.control>3)return;
  if(f.control==1)return;
  if((f.control==2 || f.control==3) && (f.from!=0 || !f.packet.valid() || f.packet.from!=0 ||
     f.packet.to!=ID || f.packet.kind!=0))return;
  if((ID==0 && f.from==0) || (ID!=0 && f.from!=0))return;
  uint8_t sender[6],self[6];mac(f.from,sender);mac(ID,self);
  if(memcmp(info->src_addr,sender,6) || memcmp(info->des_addr,self,6))return;
  if(!f.control && (!f.packet.valid() || f.packet.from!=f.from || f.packet.to!=ID ||
     f.packet.kind!=(ID==0?1:0)))return;
  xQueueSend(inbox,&rx,0); // Callback only queues bytes; controller work stays in loop().
}
// MPU diagnostics use fields already present in the V3 56-byte radio packet.
// For OBUs only: age=sample age(ms), sampleSeq=sample number, p2p=issue,
// rms10=calibration sample count. FSU meanings and handling are unchanged.
enum MpuIssue:uint8_t {MPU_OK,MPU_MISSING,MPU_ID,MPU_CONFIG_IO,MPU_CONFIG_VERIFY,
  MPU_WARMUP,MPU_CALIBRATING,MPU_NOT_FLAT,MPU_MOVING,MPU_READ,
  MPU_NO_DATA,MPU_ACCEL,MPU_CLIPPED,MPU_TIMEOUT,MPU_STALE};
const char* mpuIssueName(uint16_t n){
  const char* names[]={"OK","NO I2C DEVICE","UNSUPPORTED ID","CONFIG I2C ERROR",
    "CONFIG READBACK","WARMUP","CALIBRATING","NOT FLAT / Z UP",
    "MOVING / VIBRATION","I2C READ FAILED","NO DATA READY",
    "INVALID ACCEL","SENSOR SATURATED","CAL TIMEOUT","STALE SAMPLE"};
  return n<=MPU_STALE?names[n]:"UNKNOWN MPU ERROR";
}

class Controller {
 public:
  // FSU owns wildlife decisions. The dashboard activates FSU polling after S1-S8.
  static constexpr bool REQUIRE_FSU_REGION_HANDOFF=false;
  FailoverRadio radio;
  bool hairpinRegionReady=false;
  // The V3 FSU reports verified wildlife state through the existing RPU LoRa poll.
  // A software handoff is used for this demo because ultrasonic sensors are not yet installed.
  bool forestEnabled()const{return false;} // Independent Wi-Fi FSU never polled by traffic RPU.
  Reason forest(){
    if(!forestEnabled())return NORMAL;
    if(alarm)return WILDLIFE;
    if(!fresh(3))return FSU_LOST;
    if(!quiet || !sensorSeq || ms()-sensorAt>=2500)return SENSOR;
    return NORMAL;
  }
  Type vehicleFor(uint8_t id)const{
    if(customConfig && id>=1 && id<=2)return (Type)configuredType[id-1];
    return vehicle(scene,id);
  }
  bool safeControlPoint()const{
    if(grants)return false;
    for(uint8_t i=1;i<=2;i++)if(peer[i].seen){uint16_t x=peer[i].p.pos;if(x>=BEND_IN && x<BEND_OUT)return false;}
    return true;
  }
  uint8_t motionFor(uint8_t id){
    if(phase!=RUN || !matched(id) || !cars())return DISPLAY_WAIT;
    const uint16_t x=peer[id].p.pos;
    if(REQUIRE_FSU_REGION_HANDOFF && !hairpinRegionReady)return DISPLAY_WAIT;
    if(scene==0)return DISPLAY_GO;
    if(scene==5 && id==2 && x<BEND_GATE && vehicleFor(2)==FIRE)return DISPLAY_SLOW;
    if(scene==6){const Reason state=forest();return state==NORMAL?DISPLAY_SLOW:DISPLAY_WAIT;}
    if(x<BEND_GATE)return DISPLAY_GO;
    if(x<BEND_OUT){if(grants&(1<<(id-1)))return DISPLAY_GO;if((scene==3||scene==5)&&x<BEND_IN-10)return DISPLAY_SLOW;return DISPLAY_WAIT;}
    return DISPLAY_GO;
  }
  void copySafeName(char* dst,const char* src,const char* fallback){
    uint8_t out=0;
    for(uint8_t in=0;src && src[in] && out<11;in++){
      char c=src[in];
      if((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='-')dst[out++]=c;
      else if(c==' '||c=='.')dst[out++]='_';
    }
    if(!out){while(fallback[out]&&out<11){dst[out]=fallback[out];out++;}}
    dst[out]=0;
  }
  void emitDashboardStatus(){
    const char* lora=radio.restoringPrimary()?"PROBING":radio.usingWiFi()?"FAILED":radio.loraReady()?"PRIMARY":"DOWN";
    const char* wifi=radio.usingWiFi()?radio.badge():radio.backupReady()?"STANDBY":"NOT_READY";
    const bool confirmed=radio.peerWiFi(1)&&radio.peerWiFi(2);
    if(scene==7 && s8Injected && radio.usingWiFi()&&confirmed)recoveryVerified=true;
    const char* decision=phase==PAUSED?"PAUSED":phase==FAULT?"FAULT":grants?reasons[grantReason]:scenarioStarted?"AWAITING RESERVATION":"READY";
    Serial.printf("DASH_STATUS|{\"protocol\":4,\"build\":\"V2X-DASH-4\",\"session\":%lu,\"scene\":%u,\"round\":%u,\"phase\":%u,\"grant\":%u,\"started\":%u,\"manual\":%u,\"completedMask\":%u,\"completedRound\":%u,\"recoveryVerified\":%u,\"wifiConfirmed\":%u,\"lora\":\"%s\",\"wifi\":\"%s\",\"decision\":\"%s\"",
      (unsigned long)boot,scene+1,round,phase,grants,scenarioStarted,manualMode,completedScenarioMask,completedRound,recoveryVerified,confirmed,lora,wifi,decision);
    for(uint8_t i=1;i<=2;i++){
      const Packet& p=peer[i].p;const bool current=matched(i);
      const uint8_t cmd=phase==RUN&&current?p.motion:DISPLAY_WAIT;
      const float angle=p.mpu==2?p.pitch/100.0f:0;
      Serial.printf(",\"obu%u\":%u,\"pos%u\":%u,\"cmd%u\":%u,\"type%u\":%u,\"name%u\":\"%s\",\"mpu%u\":%u,\"pitch%u\":%.2f,\"age%u\":%u,\"peerRound%u\":%u,\"lastSeq%u\":%lu,\"limit%u\":%u,\"reason%u\":\"%s\",\"cal%u\":%u,\"issue%u\":%u",
        i,current,i,p.pos,i,cmd,i,vehicleFor(i),i,configuredName[i-1],i,current?p.mpu:0,i,angle,i,p.age,i,p.round,i,(unsigned long)p.seq,i,p.limit,i,reasons[p.reason<=COMPLETE?p.reason:SYNC],i,p.rms10,i,p.p2p);
    }
    Serial.printf(",\"shieldDevice\":%lu,\"shieldSeq\":%lu,\"shieldActive\":%u,\"s8Injected\":%u",
      (unsigned long)shieldDevice,(unsigned long)shieldSeq,shieldActive,s8Injected);
    Serial.printf(",\"shieldAnimal\":%u,\"restoringPrimary\":%u",shieldAnimal,radio.restoringPrimary());
    for(uint8_t i=1;i<=2;i++){
      const Packet& p=peer[i].p;
      const bool ack=shieldDevice && matched(i) && p.shieldDevice==shieldDevice && p.shieldSeq==shieldSeq && p.shieldActive==shieldActive && p.shieldAnimal==shieldAnimal;
      const char* block=!fresh(i)?"OBU RESPONSE MISSING":!matched(i)?"WAITING FOR ROUND SYNCHRONIZATION":
        scene==3 && mpuProblem(i)?mpuProblem(i):phase==RESET&&scenarioStarted&&p.pos!=0?"WAITING FOR ZERO POSITION":"READY";
      Serial.printf(",\"shieldAck%u\":%u,\"block%u\":\"%s\",\"replyAge%u\":%lu,\"peerBoot%u\":%lu,\"sampleSeq%u\":%lu",
        i,ack,i,block,i,(unsigned long)(peer[i].seen?ms()-peer[i].at:65535),i,(unsigned long)peer[i].boot,i,(unsigned long)p.sampleSeq);
    }
    Serial.println("}");
  }
  void dashboardAck(const char* action,const char* detail="OK"){Serial.printf("DASH_ACK|%s|%s\n",action,detail);}
  void dashboardError(const char* action,const char* detail){Serial.printf("DASH_ERR|%s|%s\n",action,detail);}
  void handleDashboardLine(char* line){
    char* root=strtok(line,"|");char* action=strtok(nullptr,"|");
    if(!root||strcmp(root,"DASH")||!action)return;
    if(!strcmp(action,"HELLO")){dashboardAck("HELLO","PROTO=4;BUILD=V2X-DASH-4;PACKET=V5_68;BAUD=115200;WILDLIFE=INDEPENDENT");emitDashboardStatus();return;}
    if(!strcmp(action,"STATUS")){dashboardAck("STATUS");emitDashboardStatus();return;}
    if(!strcmp(action,"RESTORE_LORA")){
      if(scenarioStarted || !safeControlPoint() || !radio.usingWiFi()){dashboardError(action,"IDLE_BACKUP_REQUIRED");return;}
      radio.injectPrimaryLoss(false);radio.restorePrimary();dashboardAck(action,"PROBING_PRIMARY_HANDSHAKE");emitDashboardStatus();return;
    }
    if(!strcmp(action,"SHIELD")){dashboardError(action,"USE_WILDLIFE_ALERT_OR_WILDLIFE_CLEAR_WITH_ANIMAL");return;}
    if(!strcmp(action,"WILDLIFE_ALERT") || !strcmp(action,"WILDLIFE_CLEAR")){
      const bool active=!strcmp(action,"WILDLIFE_ALERT");
      uint32_t values[3];
      for(uint8_t i=0;i<3;i++){
        char* v=strtok(nullptr,"|");if(!v||!*v||strlen(v)>10){dashboardError(action,"FIELDS");return;}
        uint64_t x=0;for(char* c=v;*c;c++){if(*c<'0'||*c>'9'){dashboardError(action,"INVALID_INTEGER");return;}x=x*10+(*c-'0');}
        if(x>UINT32_MAX){dashboardError(action,"RANGE");return;}values[i]=x;
      }
      if(strtok(nullptr,"|") || !values[0] || !values[1] || values[2]>2 || (active&&!values[2])){dashboardError(action,"RANGE");return;}
      if(shieldDevice==values[0] && (values[1]<shieldSeq || (values[1]==shieldSeq && (shieldActive!=active || shieldAnimal!=values[2])))){dashboardError(action,"OLD_OR_CONFLICTING_EVENT");return;}
      shieldDevice=values[0];shieldSeq=values[1];shieldAnimal=values[2];shieldActive=active;
      dashboardAck(action,"ACCEPTED");emitDashboardStatus();return;
    }
    if(!strcmp(action,"LINK_TEST")){
      if(scene!=7||!scenarioStarted||phase!=RUN||!cars()||radio.usingWiFi()){dashboardError("LINK_TEST","S8_PRIMARY_RUNNING_REQUIRED");return;}
      s8Injected=true;radio.injectPrimaryLoss();
      dashboardAck("LINK_TEST","PRIMARY_TRAFFIC_SUPPRESSED");emitDashboardStatus();return;
    }
    if(!strcmp(action,"FSU_STAGE")){dashboardError("FSU_STAGE","INDEPENDENT_WIFI_LAB");return;}
    if(!strcmp(action,"STOP")){
      if(!safeControlPoint()){dashboardError("STOP","BEND_OCCUPIED; WAIT_FOR_CLEARANCE");return;}
      scenarioStarted=false;resetRound(false);cycleStarted=false;completedRound=0;
      dashboardAck("STOP","IDLE");emitDashboardStatus();return;
    }
    if(!strcmp(action,"START")){
      if(radio.restoringPrimary()){dashboardError(action,"WAIT_FOR_PRIMARY_RESTORE_HANDSHAKE");return;}
      char* sc=strtok(nullptr,"|");char* t1=strtok(nullptr,"|");char* t2=strtok(nullptr,"|");char* n1=strtok(nullptr,"|");char* n2=strtok(nullptr,"|");
      if(!sc||!t1||!t2||!n1||!n2){dashboardError("START","FIELDS");return;}
      char *e0,*e1,*e2;int si=strtol(sc,&e0,10),a=strtol(t1,&e1,10),b=strtol(t2,&e2,10);
      if(*e0||*e1||*e2||!sc[0]||!t1[0]||!t2[0]){dashboardError("START","INVALID_INTEGER");return;}
      if(si==7 && radio.usingWiFi()){dashboardError("START","RESTART_ALL_TRAFFIC_BOARDS_TO_RESTORE_LORA");return;}
      if(si==6){dashboardError("START","S7_INDEPENDENT_WIFI_LAB");return;}
      if(si<0||si>=CASES||a<0||a>EMPTY||b<0||b>EMPTY){dashboardError("START","RANGE");return;}
      if(scenarioStarted || phase==RUN || phase==PAUSED){dashboardError("START","SCENARIO_ALREADY_ACTIVE");return;}
      if(scenariosComplete || fsuStageActive){dashboardError("START","SCENARIO_SEQUENCE_LOCKED_FSU_STAGE_ACTIVE");return;}
      if(REQUIRE_FSU_REGION_HANDOFF && !hairpinRegionReady){dashboardError("START","WAIT_FOR_FSU_CLEAR_HANDOFF");return;}
      if(!safeControlPoint()){dashboardError("START","BEND_OCCUPIED");return;}
      scene=(uint8_t)si;configuredType[0]=(uint8_t)a;configuredType[1]=(uint8_t)b;
      copySafeName(configuredName[0],n1,"OBU1");copySafeName(configuredName[1],n2,"OBU2");
      // Manual mode uses the operator's selected vehicle types. Automatic
      // mode must use the built-in vehicle pair for each of the eight scenes.
      customConfig=manualMode;scenarioStarted=true;if(phase==PAUSED)phase=pausedPhase;
      resetRound(false);dashboardAck("START","ACCEPTED");emitDashboardStatus();return;
    }
    if(!strcmp(action,"PAUSE")){
      if(phase==PAUSED){dashboardAck("PAUSE","ALREADY_PAUSED");return;}
      if(!safeControlPoint()){dashboardError("PAUSE","BEND_OCCUPIED; WAIT_FOR_CLEARANCE");return;}
      pausedPhase=phase;pausedAt=ms();phase=PAUSED;dashboardAck("PAUSE","ACCEPTED");return;
    }
    if(!strcmp(action,"RESUME")){
      if(phase!=PAUSED){dashboardError("RESUME","NOT_PAUSED");return;}
      const uint32_t held=ms()-pausedAt;phase=pausedPhase;phaseAt+=held;cycleAt+=held;dashboardAck("RESUME","ACCEPTED");return;
    }
    if(!strcmp(action,"RESET")){
      if(!safeControlPoint()){dashboardError("RESET","BEND_OCCUPIED; WAIT_FOR_CLEARANCE");return;}
      if(phase==PAUSED){phase=pausedPhase;}
      scenarioStarted=false;resetRound(false);cycleStarted=false;completedRound=0;dashboardAck("RESET","IDLE");emitDashboardStatus();return;
    }
    if(!strcmp(action,"MODE")){
      char* m=strtok(nullptr,"|");if(!m){dashboardError("MODE","MISSING_VALUE");return;}
      if(!strcmp(m,"MANUAL")){
        if(scenarioStarted || phase==PAUSED){dashboardError("MODE","FINISH_OR_RESET_ACTIVE_SCENARIO_FIRST");return;}
        manualMode=true;customConfig=false;completedScenarioMask=0;scenariosComplete=false;fsuStageActive=false;
        hairpinRegionReady=true;dashboardAck("MODE","MANUAL");emitDashboardStatus();return;
      }
      if(!strcmp(m,"AUTO")){dashboardError("MODE","AUTO_SEQUENCE_OWNED_BY_DASHBOARD");return;}
      if(!strcmp(m,"LEGACY_AUTO_DISABLED")){
        if(scenarioStarted || phase==PAUSED){dashboardError("MODE","FINISH_OR_RESET_ACTIVE_SCENARIO_FIRST");return;}
        manualMode=false;customConfig=false;completedScenarioMask=0;scenariosComplete=false;fsuStageActive=false;scenarioStarted=false;hairpinRegionReady=true;
        copySafeName(configuredName[0],"OBU1","OBU1");copySafeName(configuredName[1],"OBU2","OBU2");
        dashboardAck("MODE","AUTO");emitDashboardStatus();return;
      }
      dashboardError("MODE","UNKNOWN_VALUE");return;
    }
    dashboardError("COMMAND","UNKNOWN_ACTION");
  }
  void serviceSerial(){
    while(Serial.available()){
      uint8_t c=(uint8_t)Serial.read();
      if(c=='\r')continue;
      if(c=='\n'){serialBuffer[serialLength]='\0';if(serialLength)handleDashboardLine(serialBuffer);serialLength=0;continue;}
      if(serialLength==0&&(c=='R'||c=='r')){if(phase==FAULT)resetRound(false);continue;}
      if(serialLength==0&&(c=='F'||c=='f')){radio.testFailover();continue;}
      if(serialLength<sizeof(serialBuffer)-1)serialBuffer[serialLength++]=(char)c;else serialLength=0;
    }
  }
  struct Peer {Packet p;uint32_t at=0,boot=0,requestAt=0;bool seen=false,requested=false;} peer[4];
  uint32_t boot=0,seq=0,sentAt=0,gapAt=0,phaseAt=0,collectAt=0,logAt=0;
  uint16_t round=1;uint8_t scene=0,phase=RESET,target=1,grants=0,tie=1;
  Reason grantReason=FIRST;
  bool pending=false,collecting=false;
  uint32_t sensorSeq=0,sensorAt=0;
  bool alarm=false,quiet=false;
  // Eight traffic scenarios are completed first. The FSU is polled only after
  // the operator explicitly enters the final wildlife stage from the dashboard.
  uint32_t shieldDevice=0,shieldSeq=0;uint8_t shieldActive=0,shieldAnimal=0;
  bool s8Injected=false;
  uint16_t completedRound=0;
  bool recoveryVerified=false;
  uint8_t completedScenarioMask=0;
  bool scenariosComplete=false,fsuStageActive=false;
  bool manualMode=true,customConfig=false;
  bool scenarioStarted=false; // No scenario is transmitted to the OLEDs until DASH|START.
  uint8_t configuredType[2]={CAR,CAR};
  char configuredName[2][12]={{"OBU1"},{"OBU2"}};
  uint8_t pausedPhase=RESET;uint32_t pausedAt=0;
  char serialBuffer[180];uint8_t serialLength=0;
  uint32_t dashStatusAt=0;
  uint32_t diagAt=0,cycleAt=0;bool cycleStarted=false;
  uint32_t elapsed(){return cycleStarted?ms()-cycleAt:0;}
  bool urgentDisplay(){return phase==FAULT || (phase==RUN && (!cars() || needsMPU()));}
  uint8_t displayStage(){
    if(phase==RESET && !scenarioStarted)return 3; // OLED standby splash; never expose a scenario before START.
    return urgentDisplay()?3:phase!=RUN?0:elapsed()>=SCENARIO_MS?1:elapsed()/DISPLAY_STAGE_MS;
  }
  uint32_t expected=0;
  void setup(){Serial.begin(115200);delay(400);boot=newBoot();Serial.println("MPU FIX: CAL-PITCH-2 (V3 transport retained)");radio.begin();
    hairpinRegionReady=true;scene=0;target=1;scenarioStarted=false;sensorSeq=0;sensorAt=0;alarm=false;quiet=false;
    completedScenarioMask=0;scenariosComplete=false;fsuStageActive=false;
    Serial.println("RPU STANDBY: traffic S1-S6/S8; S7 is an independent Wi-Fi test");
    Serial.println("Ultrasonic Sensor 1/2 are intentionally not used in this submission build");
    Serial.println("Dashboard sequences traffic rounds and independent Wi-Fi wildlife test");
    Serial.println("Dashboard controls Manual or Automatic S1-S8; USB 115200 baud");
    Serial.println("DASH|HELLO protocol v4; BUILD=V2X-DASH-4; PACKET=V5_68");}
  bool fresh(uint8_t id){return peer[id].seen && ms()-peer[id].at<LIVE;}
  bool matched(uint8_t id){return fresh(id) && peer[id].p.round==round;}
  bool cars(){return matched(1)&&matched(2);}
  void resetRound(bool advance){
    if(advance)scene=(scene+1)%CASES;
    if(!++round)++round;
    phase=RESET;phaseAt=ms();cycleAt=ms();cycleStarted=true;grants=0;collecting=false;completedRound=0;recoveryVerified=false;s8Injected=false;
    for(int i=1;i<=2;i++){peer[i].requested=false;peer[i].requestAt=0;}
    Serial.printf("ROUND %u SCENE %s: resetting virtual positions\n",round,scenes[scene]);
  }
  // OBU age is measured when its reply is built. Allow 120 ms for LoRa
  // transport plus local receive age; do not confuse a fresh packet with a fresh sensor.
  const char* mpuProblem(uint8_t id){
    const Packet& p=peer[id].p;
    if(!matched(id))return "OBU STATUS/ROUND STALE";
    if(p.mpu!=2)return p.p2p && p.p2p<=MPU_STALE?mpuIssueName(p.p2p):
      p.mpu==0?"MPU INIT FAILED":p.mpu==1?"NOT CALIBRATED":"MPU INVALID/STALE";
    if(!p.sampleSeq || p.age==65535)return "NO SAMPLE METADATA: UPDATE OBU";
    if(p.age>=200 || (uint32_t)p.age+120+(ms()-peer[id].at)>=1000)return "PITCH SAMPLE TOO OLD";
    if(p.pitch < -9000 || p.pitch > 9000)return "PITCH OUT OF RANGE";
    return nullptr;
  }
  void reportMPU(){
    if(phase!=RUN)return;
    bool approach=false;
    for(int i=1;i<=2;i++)approach|=peer[i].requested && peer[i].p.pos<BEND_OUT;
    if(!approach)return;
    for(int i=1;i<=2;i++){
      const Packet& p=peer[i].p;const char* why=mpuProblem(i);
      Serial.printf("MPU RX OBU%u: pitch=%+.2f deg state=%u sample=%lu age-at-send=%u ms reply-age=%lu ms cal=%u/150 status=%s threshold=+40.00 deg\n",
        i,why?NAN:p.pitch/100.0,p.mpu,(unsigned long)p.sampleSeq,p.age,
        (unsigned long)(ms()-peer[i].at),p.rms10,why?why:"VALID");
      if(p.p2p==MPU_TIMEOUT)Serial.printf("MPU CAL TIMEOUT OBU%u last cause=%s\n",i,mpuIssueName(p.hz10));
      if(why && peer[i].requested && p.pos<BEND_OUT && vehicleFor(i)==TRUCK){
        if(p.mpu==1)Serial.printf("MPU PRIORITY WAIT OBU%u: automatic calibration is still running; keep sensor still and level; no C command needed.\n",i);
        else Serial.printf("MPU PRIORITY WAIT OBU%u: %s. Check sensor power/wiring and OBU diagnostics; no round reset needed.\n",i,why);
      }
    }
  }
  bool needsMPU(){
    // Preserve the submitted V3 priority rule: MPU validity is required only
    // for S4 (two loaded trucks), where uphill pitch breaks the tie.
    // S2/S3 and other truck scenarios must not be blocked by MPU calibration.
    if(scene!=3)return false;
    for(int i=1;i<=2;i++)if(peer[i].requested && peer[i].p.pos<BEND_OUT &&
      vehicleFor(i)==TRUCK && mpuProblem(i)!=nullptr)return true;
    return false;
  }
  void select(){
    uint8_t candidates=0;
    for(int i=1;i<=2;i++)if(peer[i].requested && peer[i].p.pos<BEND_OUT)candidates|=1<<(i-1);
    if(!candidates || needsMPU())return;
    if(scene==0 || scene==6){grants=candidates;grantReason=BOTH;}
    else if(candidates==1 || candidates==2){grants=candidates;grantReason=FIRST;}
    else{
      bool e1=vehicleFor(1)==AMBULANCE||vehicleFor(1)==FIRE;bool e2=vehicleFor(2)==AMBULANCE||vehicleFor(2)==FIRE;
      bool u1=vehicleFor(1)==TRUCK && peer[1].p.pitch>=4000;
      bool u2=vehicleFor(2)==TRUCK && peer[2].p.pitch>=4000;
      if(e1!=e2){grants=e1?1:2;grantReason=EMERGENCY;}
      else if(!e1 && !e2 && (vehicleFor(1)==TRUCK)!=(vehicleFor(2)==TRUCK)){
        grants=vehicleFor(1)==TRUCK?1:2;grantReason=UPHILL;
      }else{
        int32_t arrival=(int32_t)(peer[1].requestAt-peer[2].requestAt);
        bool simultaneous=arrival>=-(int32_t)ARRIVAL_TIE_MS && arrival<=(int32_t)ARRIVAL_TIE_MS;
        if(scene==3 && simultaneous && u1!=u2){grants=u1?1:2;grantReason=UPHILL;}
        else{grants=arrival==0?tie:arrival<0?1:2;grantReason=FIRST;tie=tie==1?2:1;}
      }
    }
    collecting=false;
    Serial.printf("GRANT mask=%u reason=%s pitch1=%.1f pitch2=%.1f\n",grants,
      reasons[grantReason],peer[1].p.pitch/100.0,peer[2].p.pitch/100.0);
  }
  void update(){
    if(phase==FAULT || phase==PAUSED)return;
    if(phase==RESET){
      if(!scenarioStarted)return; // Keep radio supervision alive, but hold both OBUs in the welcome screen.
      bool ready=cars() && peer[1].p.pos==0 && peer[2].p.pos==0 &&
        (!REQUIRE_FSU_REGION_HANDOFF || hairpinRegionReady);
      // The original firmware gates only S4 (two loaded trucks) on MPU
      // calibration/validity; do not block S2/S3 because one vehicle is a truck.
      if(scene==3){
        for(uint8_t i=1;i<=2;i++)if(vehicleFor(i)==TRUCK && mpuProblem(i))ready=false;
      }
      if(ready){phase=RUN;phaseAt=ms();if(!cycleStarted){cycleAt=ms();cycleStarted=true;}}
      return;
    }
    if(scene==7 && scenarioStarted && phase==RUN && !s8Injected && !radio.usingWiFi() && cars() && elapsed()>=5000){
      s8Injected=true;radio.injectPrimaryLoss();Serial.println("S8 TEST: primary traffic suppressed; waiting for real timeout and backup replies");
    }
    if(!cars())return; // Never release grants on a link timeout.
    if(REQUIRE_FSU_REGION_HANDOFF && !hairpinRegionReady){grants=0;collecting=false;return;}
    for(int i=1;i<=2;i++){
      uint8_t bit=1<<(i-1);uint16_t x=peer[i].p.pos;
      if(x>=BEND_GATE && x<BEND_OUT && !peer[i].requested){
        peer[i].requested=true;peer[i].requestAt=ms();
        Serial.printf("OBU%u APPROACH -> REQUEST\n",i);
      }
      if((grants&bit) && x>=BEND_OUT){grants&=~bit;Serial.printf("OBU%u EXIT CONFIRMED\n",i);}
    }
    if(!grants){
      bool any=false;for(int i=1;i<=2;i++)any|=peer[i].requested && peer[i].p.pos<BEND_OUT;
      if(any && !collecting){collecting=true;collectAt=ms();}
      if(collecting && ms()-collectAt>=400)select(); // Preserve the submitted V3 arbitration collection window.
    }
    // Record a scenario only after both current-round OBUs have physically
    // reported the virtual endpoint and the conflict grant is released.
    const bool bothFinished=matched(1)&&matched(2)&&peer[1].p.pos>=FINISH&&peer[2].p.pos>=FINISH&&!grants;
    if(scenarioStarted && phase==RUN && bothFinished && (scene!=7 || recoveryVerified)){
      completedRound=round;
      completedScenarioMask|=(uint8_t)(1u<<scene);
      if(false){
        scenariosComplete=true;scenarioStarted=false;fsuStageActive=false;phase=RESET;grants=0;collecting=false;
        Serial.println("ALL EIGHT SCENARIOS COMPLETE: dashboard may now activate the final FSU wildlife stage");
      }else if(manualMode){
        scenarioStarted=false;phase=RESET;grants=0;collecting=false;
        Serial.printf("SCENARIO S%u COMPLETE: manual mode; completed mask=0x%02X\n",scene+1,completedScenarioMask);
        emitDashboardStatus();
      }else if(elapsed()>=SCENARIO_MS && forest()==NORMAL){
        resetRound(true);
      }
    }
  }
  Packet command(){
    Packet p;p.hub=boot;p.seq=++seq;if(!seq)p.seq=seq=1;
    p.from=0;p.to=target;p.boot=peer[target].boot;p.round=round;p.phase=(phase==PAUSED?(uint8_t)RESET:(uint8_t)phase);p.scene=scene;
    p.sceneElapsed=elapsed();p.stage=displayStage();p.nextScene=(scene+1)%CASES;
    p.ownType=target<=2?vehicleFor(target):CAR;
    p.shieldDevice=shieldDevice;p.shieldSeq=shieldSeq;p.shieldActive=shieldActive;p.shieldAnimal=shieldAnimal;
    p.ttl=LEASE;p.reason=SYNC;
    if(target==3)return p;
    p.pos=peer[target].p.pos;p.limit=p.pos;
    if(phase==FAULT){p.reason=RESTART;return p;}
    if(phase!=RUN){p.reason=SYNC;return p;}
    if(!cars()){p.reason=LINK;return p;}
    uint16_t x=p.pos;
    if(REQUIRE_FSU_REGION_HANDOFF && !hairpinRegionReady){p.reason=SENSOR;p.motion=DISPLAY_WAIT;return p;}
    if(scene==6){
      p.reason=forest();
      if(p.reason==NORMAL){p.limit=FINISH;p.motion=DISPLAY_SLOW;}
      else if(x<FOREST_IN-10){p.limit=FOREST_IN-10;p.motion=DISPLAY_SLOW;}
      else if(x>=FOREST_OUT){p.limit=FINISH;p.motion=DISPLAY_SLOW;}
      return p;
    }
    if(scene==0){p.limit=FINISH;p.reason=BOTH;}
    else if(x<BEND_GATE){p.limit=BEND_GATE;p.reason=APPROACH;}
    else if(x<BEND_OUT){
      if(grants&(1<<(target-1))){p.limit=BEND_OUT;p.reason=grantReason;}
      else{
        p.reason=needsMPU()?MPU_CHECK:QUEUE;
        // Reserved approach space, outside the conflict, permits a real slow approach.
        if(p.reason==QUEUE && (scene==3 || scene==5) && x<BEND_IN-10){
          p.limit=BEND_IN-10;p.motion=DISPLAY_SLOW;
        }
      }
    }else{p.limit=FINISH;p.reason=x==FINISH?COMPLETE:NORMAL;}
    if(p.limit>x && p.motion!=DISPLAY_SLOW)p.motion=DISPLAY_GO;
    // S6 stages an actual later arrival; no fabricated SLOW/GO on the OLED.
    if(scene==5 && target==2 && x<BEND_GATE)p.motion=DISPLAY_SLOW;
    return p;
  }
  void next(){pending=false;target=forestEnabled()?(target==3?1:target==1?2:3):(target==1?2:1);gapAt=ms();}
  void accept(const Packet& p){
    if(!pending || p.kind!=1 || p.from!=target || p.hub!=boot || p.seq!=expected || !p.boot)return;
    if(!radio.restoringPrimary() || (p.round==round && p.boot==peer[target].boot))radio.accepted(p);
    Peer& c=peer[target];bool reboot=c.boot!=p.boot;
    if(target<=2 && c.boot && reboot && phase!=RESET){
      phase=FAULT;Serial.println("OBU REBOOT: reservation retained. Send R for virtual reset.");
    }
    if(target<=2 && !reboot && phase==RUN && p.round==round && p.pos<c.p.pos){phase=FAULT;}
    c.boot=p.boot;c.p=p;c.at=ms();c.seen=true;
    if(target==3){
      const uint32_t sensorAge=(uint32_t)p.age+120;
      if(reboot){sensorSeq=0;quiet=false;alarm=false;}
      if(p.wildlife==2)alarm=true;
      if(p.wildlife!=1 || sensorAge>=2500)quiet=false;
      if(p.sampleSeq && (!sensorSeq || newer(p.sampleSeq,sensorSeq))){
        sensorSeq=p.sampleSeq;sensorAt=ms()-sensorAge;
        quiet=(p.wildlife==1 && sensorAge<2500);
        if(quiet)alarm=false;
        if(p.wildlife==2)alarm=true;
      }
    }
    next();
  }
  void loop(){
    radio.tick();Packet p;while(radio.read(p))accept(p);
    serviceSerial();
    update();
    if(pending && ms()-sentAt>=450)next();
    if(!pending && !radio.busy && ms()-gapAt>=70){
      Packet q=command();if(radio.send(q)){expected=q.seq;sentAt=ms();pending=true;}
    }
    if(ms()-logAt>=1000){logAt=ms();reportMPU();Serial.printf(
      "LIVE started=%u round=%u scene=%u phase=%u OBU1=%u/%u OBU2=%u/%u grant=%u REGION=%s FSU=%s\n",
      scenarioStarted,round,scene+1,phase,peer[1].p.pos,fresh(1),peer[2].p.pos,fresh(2),grants,hairpinRegionReady?"HAIRPIN_READY":"WAIT_FSU_CLEAR",forestEnabled()?reasons[forest()]:"NOT_REQUIRED");}
    if(ms()-diagAt>=3000){
      diagAt=ms();radio.diagnostics();
      if(phase==RESET || phase==COUNT){
        Serial.printf("SYNC CHECK round=%u scene=%u OBU1 fresh=%u round=%u pos=%u OBU2 fresh=%u round=%u pos=%u REGION=%s FSU=%s\n",
          round,scene+1,fresh(1),peer[1].p.round,peer[1].p.pos,
          fresh(2),peer[2].p.round,peer[2].p.pos,hairpinRegionReady?"HAIRPIN_READY":"WAIT_FSU_CLEAR",forestEnabled()?reasons[forest()]:"NOT_REQUIRED");
      }
    }
    if(ms()-dashStatusAt>=250){dashStatusAt=ms();emitDashboardStatus();}
    delay(1);
  }
};
Controller app;
}
void setup(){Demo::app.setup();}
void loop(){Demo::app.loop();}
