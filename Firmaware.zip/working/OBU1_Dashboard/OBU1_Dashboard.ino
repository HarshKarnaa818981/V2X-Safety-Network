// Eight-scenario OLED edition; actual-link fallback; synchronized presentation.
// OBU1_Route: standalone LoRa breadboard demonstration.
#define ID 1
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>
#include <esp_random.h>
#include <math.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <cstring>
namespace Demo {
// TABLETOP SIMULATION. Positions in virtual mm, never RF-derived distance.
constexpr uint32_t MAGIC=0x56525434, LIVE=3000, LEASE=2000;
constexpr uint16_t BEND_GATE=200, BEND_IN=300, BEND_OUT=500;
constexpr uint16_t FOREST_GATE=700, FOREST_IN=800, FOREST_OUT=1000, FINISH=1100;
constexpr uint8_t CASES=8;
enum Phase:uint8_t {RESET,COUNT,RUN,FAULT};
enum Reason:uint8_t {SYNC,NORMAL,APPROACH,QUEUE,UPHILL,EMERGENCY,FIRST,BOTH,
  WILDLIFE,SENSOR,FSU_LOST,LINK,MPU_CHECK,RESTART,COMPLETE};
enum Type:uint8_t {CAR,TRUCK,POLICE,AMBULANCE,FIRE,BIKE,EMPTY};
const char* types[]={"CAR","LOADED TRUCK","POLICE","AMBULANCE","FIRE TRUCK","BIKE","EMPTY TRUCK"};
const char* reasons[]={"SYNC","NORMAL","APPROACH","BEND BUSY","UPHILL LOAD","EMERGENCY",
  "FIRST COME","BOTH PASS","WILDLIFE","SENSOR","FSU LOST","LINK LOST",
  "CHECK MPU","RESET DEMO","FINISHED"};
const char* scenes[]={"NORMAL TWO-WAY TRAFFIC","EMPTY TRUCK VS CAR","LOADED TRUCK VS CAR",
  "TWO LOADED TRUCKS","AMBULANCE VS CAR","EMERGENCY CONFLICT","FOREST & WILDLIFE",
  "LORA FAILURE AND WI-FI RECOVERY"};
constexpr uint32_t DISPLAY_STAGE_MS=5000, SCENARIO_MS=15000;
constexpr uint16_t ARRIVAL_TIE_MS=250;
enum DisplayMotion:uint8_t {DISPLAY_WAIT,DISPLAY_GO,DISPLAY_SLOW};
uint32_t ms(); bool newer(uint32_t a,uint32_t b); uint32_t newBoot();
Type vehicle(uint8_t scene,uint8_t id); bool urgent(uint8_t scene,uint8_t id);
const char* zone(uint16_t pos);
uint32_t ms(){return (uint32_t)millis();}
bool newer(uint32_t a,uint32_t b){return (int32_t)(a-b)>0;}
uint32_t newBoot(){uint32_t n=esp_random();return n?n:1;}
Type vehicle(uint8_t s,uint8_t id){
  const Type v[CASES][2]={{CAR,CAR},{EMPTY,CAR},{TRUCK,CAR},{TRUCK,TRUCK},
    {AMBULANCE,CAR},{AMBULANCE,FIRE},{CAR,CAR},{CAR,CAR}};
  return s<CASES && id>=1 && id<=2?v[s][id-1]:CAR;
}
bool urgent(uint8_t s,uint8_t id){return (s==4 && id==1) || s==5;}
const char* zone(uint16_t x){
  return x<BEND_GATE?"ROAD":x<BEND_IN?"BEND APPROACH":x<BEND_OUT?"BEND":
    x<FOREST_GATE?"ROAD":x<FOREST_IN?"FOREST APPROACH":x<FOREST_OUT?"FOREST":"EXIT";
}
struct Packet {
  uint32_t magic=MAGIC,hub=0,seq=0,boot=0,sampleSeq=0;
  uint16_t round=0,pos=0,limit=0,ttl=0,age=65535,p2p=0,rms10=0,hz10=0;
  int16_t pitch=0,roll=0;
  uint8_t from=0,to=0,kind=0,phase=RESET,scene=0,reason=SYNC,mpu=0,wildlife=0;
  // V2 extension, same on all four nodes. Elapsed time is RPU-owned.
  uint32_t sceneElapsed=0;
  uint8_t stage=0,nextScene=1,ownType=CAR,motion=DISPLAY_WAIT;
  uint32_t shieldDevice=0,shieldSeq=0;
  uint8_t shieldActive=0,shieldAnimal=0,shieldReserved[2]={};
  bool valid()const{return shieldActive<=1 && shieldAnimal<=2 && stage<=3 && nextScene<CASES && ownType<=EMPTY && motion<=DISPLAY_SLOW && magic==MAGIC && hub && seq && from<=3 && to<=3 && from!=to &&
    kind<=1 && phase<=FAULT && scene<CASES && reason<=COMPLETE && pos<=FINISH &&
    limit<=FINISH && ttl<=6000 && mpu<=3 && wildlife<=2;}
};
static_assert(sizeof(Packet)==68,"Packet layout mismatch");
class Radio {
  static volatile bool txDone;
  static void onSent();
  bool txHooked=false;
 public:
  bool ready=false,busy=false;uint32_t started=0,retry=0;
  uint32_t txOK=0,txTimeout=0,rxRaw=0,rxBad=0,rxAddressed=0;
  uint8_t versionRegister(){
    SPI.beginTransaction(SPISettings(1000000,MSBFIRST,SPI_MODE0));
    digitalWrite(5,LOW);SPI.transfer(0x42);uint8_t v=SPI.transfer(0);
    digitalWrite(5,HIGH);SPI.endTransaction();return v;
  }
  void diagnostics(){
    Serial.printf("LORA DIAG node=%u init=%u busy=%u tx-done=%lu tx-timeout=%lu rx-raw=%lu rx-rejected=%lu rx-addressed=%lu\n",
      ID,ready,busy,(unsigned long)txOK,(unsigned long)txTimeout,
      (unsigned long)rxRaw,(unsigned long)rxBad,(unsigned long)rxAddressed);
  }
  void detachTx(){if(txHooked){LoRa.onTxDone(nullptr);txHooked=false;}}
  void start(){
    retry=ms();busy=false;LoRa.setPins(5,14,26);
    detachTx();txDone=false;
    // Explicit original wiring; slower SPI improves breadboard signal margin.
    LoRa.setSPI(SPI);LoRa.setSPIFrequency(1000000);
    ready=LoRa.begin(433E6);
    uint8_t version=versionRegister();
    Serial.printf("LORA CHIP node=%u RegVersion=0x%02X expected=0x12\n",ID,version);
    if(!ready){
      Serial.println("LORA INIT FAILED: SX127x version check failed; retry in 3 sec. WIFI STANDBY.");
      Serial.println("Check 3V3/GND, CS5 RST14 SCK18 MISO19 MOSI23 and module. Antenna/peer absence does NOT cause the SPI version check to fail.");
      return;
    }
    LoRa.setSpreadingFactor(7);LoRa.setSignalBandwidth(125E3);LoRa.setCodingRate4(5);
    LoRa.setPreambleLength(8);LoRa.setSyncWord(0x52);LoRa.enableCrc();LoRa.setTxPower(2);
    LoRa.receive();Serial.println("LORA READY 433MHz SF7 BW125");
  }
  void begin(){SPI.begin(18,19,23,5);start();}
  void tick(){
    if(!ready && ms()-retry>=3000)start();
    if(busy){
      if(txDone){
        ++txOK;
        // Reception is polled: detach the ISR before mapping DIO0 to RX_DONE.
        detachTx();txDone=false;busy=false;LoRa.receive();
      }else if(ms()-started>=350){
        ++txTimeout;
        detachTx();LoRa.idle();txDone=false;
        ready=busy=false;retry=ms();
        Serial.println("LORA TX TIMEOUT: check DIO0 -> GPIO26; retry in 3 sec");
      }
    }
  }
  bool send(const Packet& p){
    if(!ready || busy || !LoRa.beginPacket())return false;
    if(LoRa.write((const uint8_t*)&p,sizeof(p))!=sizeof(p)){
      LoRa.receive();return false;
    }
    txDone=false;LoRa.onTxDone(onSent);txHooked=true;
    busy=true;started=ms();
    if(!LoRa.endPacket(true)){
      detachTx();txDone=false;busy=false;LoRa.receive();return false;
    }
    return true;
  }
  bool read(Packet& p){
    if(!ready || busy)return false;
    int n=LoRa.parsePacket();if(!n)return false;++rxRaw;
    bool ok=n==(int)sizeof(p);
    if(ok){uint8_t* b=(uint8_t*)&p;for(size_t i=0;i<sizeof(p);i++)b[i]=LoRa.read();}
    while(LoRa.available())LoRa.read();LoRa.receive();
    if(!ok || !p.valid()){++rxBad;return false;}
    if(p.to!=ID)return false;
    ++rxAddressed;return true;
  }
};
volatile bool Radio::txDone=false;
// Out-of-class definition avoids Xtensa inline IRAM literal relocation errors.
void IRAM_ATTR Radio::onSent(){txDone=true;}
// Added transport only. Radio changes above only guard interrupt detachment.
// One four-node demo set: fixed locally administered MACs, channel and demo keys.
// Change the MAC prefix and BOTH keys consistently for another nearby demo set.
class FailoverRadio {
  static constexpr uint32_t TAG=0x56465831;
  static constexpr uint8_t CHANNEL=6, NODES=4;
  struct Frame {
    uint32_t tag=TAG;
    uint8_t version=5,from=ID,to=0,control=0;
    Packet packet;
  };
  struct Received {Frame frame;uint32_t at;};
  static QueueHandle_t inbox;
  static void receiveWiFi(const esp_now_recv_info_t* info,const uint8_t* bytes,int len);
  Radio lora;
  QueueHandle_t dataQueue=nullptr;
  bool wifiMode=false,wifiReady=false,espNowStarted=false;
  bool restoring=false;uint32_t restoreAt=0;
  bool postDemo=false; // Actual primary-link failure latch; no scenario-triggered fault.
  Packet lastPoll[4]; uint32_t lastRx[4]={},pollStarted[4]={},startedAt=0; bool polled[4]={};
  bool wifiSeen[NODES]={};
  uint32_t wifiAt[NODES]={};
  uint32_t knownHub=0,knownSeq=0;uint16_t knownRound=0;uint8_t knownScene=0;
  Packet completion;
  uint32_t wifiRetry=0,controlAt=0,statusAt=0,sendErrors=0,activatedAt=0;
  uint8_t controlTarget=1;
  const char* cause="NONE";
  static void mac(uint8_t node,uint8_t* out){
    const uint8_t prefix[6]={0x02,0x56,0x32,0x42,0x01,0};
    memcpy(out,prefix,6);out[5]=node;
  }
  bool setupWiFi(){
    wifiRetry=ms();wifiReady=false;
    if(espNowStarted){esp_now_deinit();espNowStarted=false;}
    if(!inbox)inbox=xQueueCreate(12,sizeof(Received));
    if(!dataQueue)dataQueue=xQueueCreate(8,sizeof(Received));
    if(!inbox || !dataQueue){Serial.println("WIFI BACKUP ERROR: queue allocation");return false;}
    WiFi.persistent(false);WiFi.setAutoReconnect(false);
    if(!WiFi.mode(WIFI_STA)){Serial.println("WIFI BACKUP ERROR: STA start");return false;}
    // Stop the interface before setting its locally administered demo MAC.
    esp_err_t e=esp_wifi_stop();
    uint8_t own[6];mac(ID,own);
    if(e==ESP_OK)e=esp_wifi_set_mac(WIFI_IF_STA,own);
    if(e==ESP_OK)e=esp_wifi_start();
    if(e==ESP_OK)e=esp_wifi_set_ps(WIFI_PS_NONE);
    if(e==ESP_OK)e=esp_wifi_set_channel(CHANNEL,WIFI_SECOND_CHAN_NONE);
    if(e==ESP_OK)e=esp_now_init();
    if(e!=ESP_OK){Serial.printf("WIFI BACKUP INIT ERROR=%d; retry in 3 sec\n",(int)e);return false;}
    espNowStarted=true;
    const uint8_t pmk[16]={0x37,0x2a,0x91,0xb5,0x18,0x43,0xf0,0x67,0xd2,0x0e,0x84,0x59,0xaa,0x6c,0x13,0xe8};
    const uint8_t lmk[16]={0x5b,0x08,0xc6,0x42,0xef,0x93,0x71,0x2d,0xa0,0x3e,0x64,0x19,0xd7,0x85,0xbc,0x20};
    e=esp_now_set_pmk(pmk);
    for(uint8_t node=0;node<NODES && e==ESP_OK;node++){
      if(node==ID || (ID!=0 && node!=0))continue;
      esp_now_peer_info_t peer={};mac(node,peer.peer_addr);
      peer.channel=CHANNEL;peer.ifidx=WIFI_IF_STA;peer.encrypt=true;
      memcpy(peer.lmk,lmk,16);e=esp_now_add_peer(&peer);
    }
    if(e==ESP_OK)e=esp_now_register_recv_cb(receiveWiFi);
    if(e!=ESP_OK){Serial.printf("WIFI BACKUP PEER ERROR=%d; retry in 3 sec\n",(int)e);return false;}
    wifiReady=true;
    Serial.printf("WIFI STANDBY READY: ESP-NOW channel %u node %u (backup waits for actual primary-link failure)\n",CHANNEL,ID);
    return true;
  }
  bool sendFrame(const Frame& f){
    if(!wifiReady)return false;
    uint8_t destination[6];mac(f.to,destination);
    esp_err_t e=esp_now_send(destination,(const uint8_t*)&f,sizeof(f));
    if(e!=ESP_OK)++sendErrors;
    return e==ESP_OK; // Queued only; existing controller reply checks prove delivery.
  }
  void activate(const char* why){
    if(wifiMode)return;restoring=false;
    wifiMode=true;cause=why;activatedAt=ms();
    lora.detachTx();
    LoRa.sleep(); // Discontinue this node's LoRa; do not call its retry loop again.
    lora.ready=false;lora.busy=false;busy=false;ready=wifiReady;
    controlAt=ms()-150;
    Serial.printf("LORA DISCONNECTED: %s | WIFI FAILOVER %s\n",cause,
      wifiReady?"ACTIVE; waiting for valid peer traffic":"PENDING: WIFI INIT ERROR");
  }
  void markFinal(){
    if(postDemo)return;
    postDemo=true;
    activate("PRIMARY LINK TIMEOUT");
  }
 public:
  bool ready=false,busy=false;
  bool usingWiFi()const{return wifiMode;}
  bool transitionVisible()const{return postDemo && ms()-activatedAt<3000;}
  bool backupReady()const{return wifiReady;}
  bool peerWiFi(uint8_t node)const{return node<NODES && wifiMode && wifiReady &&
    wifiSeen[node] && ms()-wifiAt[node]<LIVE;}
  bool loraReady()const{return lora.ready && !wifiMode && !restoring;}
  bool restoringPrimary()const{return restoring;}
  void restorePrimary(){if(!wifiMode)return;wifiMode=false;postDemo=false;restoring=true;restoreAt=ms();startedAt=ms();memset(lastRx,0,sizeof(lastRx));lora.begin();ready=lora.ready;busy=false;controlAt=ms()-150;}
  void diagnostics(){if(!wifiMode)lora.diagnostics();}
  bool wifiConfirmed()const{
    if(!wifiMode || !wifiReady)return false;
    if(ID==0){
      for(uint8_t node=1;node<NODES;node++)if(!wifiSeen[node] || ms()-wifiAt[node]>=LIVE)return false;
      return true;
    }
    return wifiSeen[0]&&ms()-wifiAt[0]<LIVE;
  }
  const char* badge()const{return !wifiReady?"WIFI ERR":wifiConfirmed()?"WIFI":"WIFI...";}
  void begin(){
    // Bring up the primary radio before preparing the backup interface.
    Serial.printf("FIRMWARE: FINAL-REPLAY-1 node=%u\n",ID);
    lora.begin();setupWiFi();startedAt=ms();
    ready=lora.ready;busy=lora.busy;
    Serial.println("LORA PRIMARY; automatic ESP-NOW backup only on actual primary reply timeout");
  }
  // Call only AFTER the existing Controller has accepted a matching packet.
  void accepted(const Packet& p){
    if(p.from>=NODES)return;
    lastRx[p.from]=ms();
    if(ID!=0 && !wifiMode && p.from==0){
      knownHub=p.hub;knownSeq=p.seq;knownRound=p.round;knownScene=p.scene;
    }
    if(wifiMode){
      bool first=!wifiSeen[p.from];wifiSeen[p.from]=true;wifiAt[p.from]=ms();
      if(first)Serial.printf("WIFI RX CONFIRMED: node %u; original packet checks passed\n",p.from);
    }
  }
  bool postDemoActive()const{return postDemo;}
  void testFailover(){Serial.println("No synthetic failure: backup is selected by actual primary-link loss.");}
  void tick(){
    if(!wifiReady && ms()-wifiRetry>=3000)setupWiFi();
    Received rx;
    while(inbox && xQueueReceive(inbox,&rx,0)==pdTRUE){
      if(ms()-rx.at>250)continue;
      if(rx.frame.control==3){
        const Packet& event=rx.frame.packet;
        if(ID!=0 && wifiMode && (!knownHub || event.hub==knownHub))restorePrimary();
      }else if(rx.frame.control==2){
        const Packet& event=rx.frame.packet;
        // Encrypted RPU control; preserve the current round and virtual position.
        if(ID!=0 && !wifiMode && (!knownHub || (event.hub==knownHub &&
           (event.seq==knownSeq || newer(event.seq,knownSeq)))))markFinal();
      }else if(!rx.frame.control && wifiMode){
        if(dataQueue)xQueueSend(dataQueue,&rx,0);
      }
    }
    if(restoring){
      const bool confirmed=ID==0?(lastRx[1]&&lastRx[2]&&ms()-lastRx[1]<LIVE&&ms()-lastRx[2]<LIVE):lastRx[0]!=0;
      if(confirmed){restoring=false;Serial.println("LORA RESTORED: matching primary poll/reply handshake confirmed");}
      else if(ms()-restoreAt>=8000){postDemo=true;activate("PRIMARY RESTORE HANDSHAKE TIMEOUT");}
      if(ID==0 && restoring && ms()-controlAt>=150){
        for(uint8_t n=1;n<=2;n++)if(polled[n]){Frame f;f.control=3;f.to=n;f.packet=lastPoll[n];sendFrame(f);}controlAt=ms();
      }
    }
    if(!wifiMode)lora.tick();
    if(ID==0 && !wifiMode && ms()-startedAt>=6000){
      // No switch is caused by entering S8, MPU calibration or a wildlife hold.
      for(uint8_t n=1;n<NODES;n++){
        if(!polled[n])continue;
        uint8_t activeScene=lastPoll[1].seq>lastPoll[2].seq?lastPoll[1].scene:lastPoll[2].scene;
        if(n==3 && activeScene!=6)continue; // FSU is required only in S7.
        uint32_t sinceRx=lastRx[n]?ms()-lastRx[n]:ms()-startedAt;
        if(sinceRx>=6000 && ms()-pollStarted[n]>=6000){markFinal();break;}
      }
    }
    if(ID==0 && wifiMode && wifiReady && ms()-controlAt>=150){
      if(polled[controlTarget]){
        Frame f;f.control=2;f.to=controlTarget;f.packet=lastPoll[controlTarget];sendFrame(f);
      }
      controlAt=ms();controlTarget=controlTarget+1<NODES?controlTarget+1:1;
    }
    ready=wifiMode?wifiReady:lora.ready;busy=wifiMode?false:lora.busy;
    if(wifiMode && ms()-statusAt>=2000){
      statusAt=ms();Serial.printf("LINK STATUS: LORA OFF | WIFI %s | fault=%s | queue-errors=%lu\n",
        !wifiReady?"INIT ERROR":wifiConfirmed()?"ACTIVE / RX CONFIRMED":"ACTIVE / WAITING FOR PEER",
        cause,(unsigned long)sendErrors);
    }
  }
  bool send(const Packet& p){
    if(ID==0 && p.to<NODES){
      if(!polled[p.to] || lastPoll[p.to].round!=p.round)pollStarted[p.to]=ms();
      lastPoll[p.to]=p;polled[p.to]=true;
    }
    if(!wifiMode){bool ok=lora.send(p);ready=lora.ready;busy=lora.busy;return ok;}
    if(p.to>=NODES || p.from!=ID)return false;
    Frame f;f.to=p.to;f.packet=p;return sendFrame(f);
  }
  bool read(Packet& p){
    if(!wifiMode)return lora.read(p);
    Received rx;
    while(dataQueue && xQueueReceive(dataQueue,&rx,0)==pdTRUE){
      if(ms()-rx.at>250)continue;
      p=rx.frame.packet;return true;
    }
    return false;
  }
};
QueueHandle_t FailoverRadio::inbox=nullptr;
void FailoverRadio::receiveWiFi(const esp_now_recv_info_t* info,const uint8_t* bytes,int len){
  if(!inbox || !info || !info->src_addr || !info->des_addr || !bytes || len!=(int)sizeof(Frame))return;
  Received rx;memcpy(&rx.frame,bytes,sizeof(Frame));rx.at=ms();
  const Frame& f=rx.frame;
  if(f.tag!=TAG || f.version!=5 || f.from>=NODES || f.from==ID || f.to!=ID || f.control>3)return;
  if(f.control==1)return;
  if((f.control==2 || f.control==3) && (f.from!=0 || !f.packet.valid() || f.packet.from!=0 ||
     f.packet.to!=ID || f.packet.kind!=0))return;
  if((ID==0 && f.from==0) || (ID!=0 && f.from!=0))return;
  uint8_t sender[6],self[6];mac(f.from,sender);mac(ID,self);
  if(memcmp(info->src_addr,sender,6) || memcmp(info->des_addr,self,6))return;
  if(!f.control && (!f.packet.valid() || f.packet.from!=f.from || f.packet.to!=ID ||
     f.packet.kind!=(ID==0?1:0)))return;
  xQueueSend(inbox,&rx,0); // Callback only queues bytes; controller work stays in loop().
}
// MPU diagnostics use previously unused OBU telemetry fields; Packet V2 is 56 bytes.
// For OBUs only: age=sample age(ms), sampleSeq=sample number, p2p=issue,
// rms10=calibration sample count. FSU meanings and handling are unchanged.
enum MpuIssue:uint8_t {MPU_OK,MPU_MISSING,MPU_ID,MPU_CONFIG_IO,MPU_CONFIG_VERIFY,
  MPU_WARMUP,MPU_CALIBRATING,MPU_NOT_FLAT,MPU_MOVING,MPU_READ,
  MPU_NO_DATA,MPU_ACCEL,MPU_CLIPPED,MPU_TIMEOUT,MPU_STALE};
const char* mpuIssueName(uint16_t n){
  const char* names[]={"OK","NO I2C DEVICE","UNSUPPORTED ID","CONFIG I2C ERROR",
    "CONFIG READBACK","WARMUP","CALIBRATING","NOT FLAT / Z UP",
    "MOVING / VIBRATION","I2C READ FAILED","NO DATA READY",
    "INVALID ACCEL","SENSOR SATURATED","CAL TIMEOUT","STALE SAMPLE"};
  return n<=MPU_STALE?names[n]:"UNKNOWN MPU ERROR";
}

class Tilt {
 public:
  // Preserve the original mounting convention: uphill gives negative raw X.
  // Set FORWARD_AXIS=1 only if the module Y axis runs along the vehicle.
  // Change PITCH_SIGN to +1 only if a nose-up test gives negative pitch.
  static constexpr uint8_t FORWARD_AXIS=0;
  static constexpr float PITCH_SIGN=-1.0f;
  static constexpr uint16_t SAMPLES=150;
  static constexpr uint32_t FRESH_MS=200;
  uint8_t address=0,identity=0;bool ok=false,cal=false,calibrating=false,valid=false;
  uint16_t count=0;uint32_t started=0,last=0,good=0,sampleSeq=0,reportAt=0;
  float pitch=0,roll=0;
  float accelOffset[3]={},gyroOffset[3]={},sum[6]={},squares[3]={},previous[3]={};
  bool previousSet=false,filterSet=false;
  MpuIssue issue=MPU_MISSING,lastCalIssue=MPU_WARMUP;
  bool read(uint8_t reg,uint8_t* b,size_t n){
    Wire.beginTransmission(address);Wire.write(reg);
    if(Wire.endTransmission(false)!=0)return false;
    if(Wire.requestFrom(address,n,true)!=n){while(Wire.available())Wire.read();return false;}
    for(size_t i=0;i<n;i++){int v=Wire.read();if(v<0)return false;b[i]=(uint8_t)v;}
    return true;
  }
  bool write(uint8_t reg,uint8_t v){
    Wire.beginTransmission(address);Wire.write(reg);Wire.write(v);
    return Wire.endTransmission()==0;
  }
  bool configure(uint8_t reg,uint8_t value,uint8_t mask=0xFF){
    uint8_t actual=0;
    if(!write(reg,value)||!read(reg,&actual,1)){
      issue=MPU_CONFIG_IO;Serial.printf("MPU CONFIG I2C ERROR reg=0x%02X\n",reg);return false;
    }
    if((actual&mask)!=(value&mask)){
      issue=MPU_CONFIG_VERIFY;
      Serial.printf("MPU CONFIG READBACK reg=0x%02X expected=0x%02X got=0x%02X\n",reg,value,actual);return false;
    }
    return true;
  }
  void resetWindow(){count=0;memset(sum,0,sizeof(sum));memset(squares,0,sizeof(squares));previousSet=false;}
  void begin(){
    Serial.println("MPU CAL REQUEST: keep vehicle stationary, flat, sensor Z up; no scenario reset");
    ok=cal=calibrating=valid=filterSet=false;issue=MPU_MISSING;
    resetWindow();pitch=roll=0;good=0;
    memset(accelOffset,0,sizeof(accelOffset));memset(gyroOffset,0,sizeof(gyroOffset));
    bool responded=false,found=false;
    for(uint8_t candidate=0x68;candidate<=0x69;candidate++){
      address=candidate;uint8_t id=0;
      if(!read(0x75,&id,1)){Serial.printf("MPU address 0x%02X: no WHO_AM_I response\n",address);continue;}
      responded=true;Serial.printf("MPU address=0x%02X WHO_AM_I=0x%02X\n",address,id);
      if(id==0x68 || id==0x70){identity=id;found=true;break;}
    }
    if(!found){issue=responded?MPU_ID:MPU_MISSING;Serial.printf("MPU INIT NOT READY: %s; automatic retry enabled; check SDA21/SCL22 and power\n",mpuIssueName(issue));return;}
    // Retain support for the previously observed 0x70 device; it is MPU6500-compatible.
    if(!configure(0x6B,1,0x7F) || !configure(0x6C,0,0x3F) ||
       !configure(0x6A,0) || !configure(0x23,0) || !configure(0x1A,4,7) ||
       !configure(0x1B,0,0xFB) || !configure(0x1C,0,0xF8) ||
       !configure(0x19,19) || !configure(0x37,0) || !configure(0x38,1) ||
       (identity==0x70 && !configure(0x1D,4,0x0F))){
      Serial.println("MPU CONFIG NOT VERIFIED: automatic retry enabled; check wiring/power");return;
    }
    ok=true;calibrating=true;issue=MPU_WARMUP;lastCalIssue=issue;
    started=last=ms();reportAt=ms()-1000;
    Serial.printf("MPU CONFIG VERIFIED: %s address=0x%02X accel=+/-2g gyro=+/-250dps rate=50Hz; axis=%c sign=%+.0f\n",
      identity==0x68?"MPU6050":"MPU6500-compatible",address,FORWARD_AXIS?'Y':'X',PITCH_SIGN);
  }
  static int16_t word(const uint8_t* p){return (int16_t)(((uint16_t)p[0]<<8)|p[1]);}
  void reject(MpuIssue why){
    valid=false;issue=why;
    if(calibrating){lastCalIssue=why;resetWindow();}
  }
  uint32_t sampleAge()const{return sampleSeq?ms()-good:65535;}
  uint8_t state()const{return !ok?0:!cal?(calibrating?1:3):
    (!valid || sampleAge()>=FRESH_MS)?3:2;}
  MpuIssue problem()const{
    if(cal && valid && sampleAge()>=FRESH_MS)return MPU_STALE;
    return issue;
  }
  void tick(){
    if(!ok || (!cal && !calibrating))return;
    // Automatic calibration has no deadline: invalid/moving samples reset the
    // current window, and calibration continues until 150 consecutive valid
    // stationary samples are collected. A timeout must not require a manual C.
    if(ms()-started<250 || ms()-last<20)return;
    last=ms();uint8_t b[15];
    // INT_STATUS then a coherent accel/temp/gyro burst; only fresh data counts.
    if(!read(0x3A,b,sizeof(b))){reject(MPU_READ);return;}
    if(!(b[0]&1)){
      if(!sampleSeq || sampleAge()>=FRESH_MS){reject(MPU_NO_DATA);}
      return;
    }
    int16_t raw[6]={word(b+1),word(b+3),word(b+5),word(b+9),word(b+11),word(b+13)};
    for(int i=0;i<6;i++)if(raw[i]>=32760 || raw[i]<=-32760){reject(MPU_CLIPPED);return;}
    float a[3],w[3];for(int i=0;i<3;i++){a[i]=raw[i]/16384.0f;w[i]=raw[i+3]/131.0f;}
    float g=sqrtf(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]);
    if(!isfinite(g) || g<0.75f || g>1.25f){reject(MPU_ACCEL);return;}
    if(calibrating){
      float p=atan2f(-a[0],sqrtf(a[1]*a[1]+a[2]*a[2]))*57.29578f;
      float r=atan2f(a[1],a[2])*57.29578f;
      if(fabsf(g-1)>=0.12f || fabsf(p)>=15 || fabsf(r)>=15 || a[2]<0.8f){reject(MPU_NOT_FLAT);return;}
      for(int i=0;i<3;i++)if(fabsf(w[i])>8 || (previousSet && fabsf(a[i]-previous[i])>0.05f)){reject(MPU_MOVING);return;}
      // A missed window cannot join two separated calibration poses.
      if(count && ms()-good>=FRESH_MS)resetWindow();
      for(int i=0;i<3;i++){sum[i]+=a[i];sum[i+3]+=w[i];squares[i]+=a[i]*a[i];previous[i]=a[i];}
      previousSet=true;good=ms();if(!++sampleSeq)++sampleSeq;
      ++count;issue=MPU_CALIBRATING;lastCalIssue=issue;
      if(count<SAMPLES)return;
      for(int i=0;i<3;i++){
        float mean=sum[i]/count;
        if(fmaxf(0.0f,squares[i]/count-mean*mean)>0.0004f){reject(MPU_MOVING);return;}
      }
      for(int i=0;i<3;i++){accelOffset[i]=sum[i]/count-(i==2?1.0f:0.0f);gyroOffset[i]=sum[i+3]/count;}
      // One flat-pose bias estimate, not a six-face scale-factor calibration.
      cal=true;calibrating=false;valid=true;filterSet=false;pitch=roll=0;issue=MPU_OK;
      Serial.printf("MPU CAL DONE: %u valid stationary samples; accel offsets(g) X=%+.5f Y=%+.5f Z=%+.5f gyro offsets(dps) X=%+.3f Y=%+.3f Z=%+.3f\n",
        count,accelOffset[0],accelOffset[1],accelOffset[2],gyroOffset[0],gyroOffset[1],gyroOffset[2]);
      return;
    }
    for(int i=0;i<3;i++)a[i]-=accelOffset[i];
    g=sqrtf(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]);
    if(!isfinite(g) || g<0.75f || g>1.25f){reject(MPU_ACCEL);return;}
    float forward=a[FORWARD_AXIS],side=a[FORWARD_AXIS?0:1];
    float p=atan2f(PITCH_SIGN*forward,sqrtf(side*side+a[2]*a[2]))*57.29578f;
    float r=atan2f(side,a[2])*57.29578f;
    if(!isfinite(p)||!isfinite(r)){reject(MPU_ACCEL);return;}
    if(!filterSet || !valid || sampleAge()>=FRESH_MS){pitch=p;roll=r;filterSet=true;}
    else{pitch+=0.15f*(p-pitch);roll+=0.15f*(r-roll);}
    good=ms();if(!++sampleSeq)++sampleSeq;valid=true;issue=MPU_OK;
  }
  void report(){
    if(ms()-reportAt<1000)return;reportAt=ms();
    if(state()==2)Serial.printf("MPU LIVE: pitch=%+.2f deg roll=%+.2f deg age=%lu ms sample=%lu address=0x%02X\n",
      pitch,roll,(unsigned long)sampleAge(),(unsigned long)sampleSeq,address);
    else Serial.printf("MPU STATUS: %s cal=%u/%u state=%u age=%lu ms%s%s\n",mpuIssueName(problem()),count,SAMPLES,state(),
      (unsigned long)sampleAge(),issue==MPU_TIMEOUT?" last=":"",issue==MPU_TIMEOUT?mpuIssueName(lastCalIssue):"");
  }
};

class Controller {
 public:
  FailoverRadio radio;Tilt tilt;Adafruit_SSD1306 oled{128,64,&Wire,-1};
  Packet view,reply;bool screen=false,heard=false,attached=false,pending=false;
  uint32_t boot=0,hub=0,seq=0,at=0,tickAt=0,drawAt=0,logAt=0,runAt=0,mpuRetryAt=0;
  uint32_t shieldDevice=0,shieldSeq=0;uint8_t shieldActive=0,shieldAnimal=0;
  uint16_t round=0;float position=0;uint32_t diagAt=0;
  void setup(){
    Serial.begin(115200);delay(400);boot=newBoot();Serial.println("MPU FIX: CAL-PITCH-2 (transport/scenarios unchanged)");
    Wire.begin(21,22);Wire.setTimeOut(15);Wire.beginTransmission(0x3C);
    screen=Wire.endTransmission()==0 && oled.begin(SSD1306_SWITCHCAPVCC,0x3C);
    if(!screen)Serial.println("OLED ERROR: SDA21 SCL22 address0x3C");
    tilt.begin();radio.begin();tickAt=ms();mpuRetryAt=ms();
    Serial.printf("OBU%u ROUTE V2: accelerated virtual motion; MPU auto-calibration; optional C=re-zero\n",ID);
  }
  bool fresh(){return heard && ms()-at<LIVE;}
  uint16_t pos(){return (uint16_t)position;}
  bool moving(){return attached && fresh() && view.phase==RUN && ms()-at<view.ttl &&
    position<view.limit && view.motion!=DISPLAY_WAIT;}
  bool slow(){return moving() && view.motion==DISPLAY_SLOW;}
  void advance(){
    uint32_t now=ms(),dt=now-tickAt;tickAt=now;if(dt>100)dt=100;
    if(!moving())return;
    // Speed up virtual tabletop travel so a normal scene typically completes
    // in about 10-15 s, while retaining RPU limits and conflict-section grants.
    // Speeds are virtual position-units/second, not physical motor commands.
    float speed=slow()?(view.scene==6 || (view.scene==5 && pos()<BEND_GATE)?80.0f:20.0f):
      (pos()>=FOREST_GATE && pos()<FOREST_OUT?80.0f:pos()<BEND_GATE || (pos()>=BEND_OUT && pos()<FOREST_OUT)?160.0f:240.0f);
    position=fminf((float)view.limit,position+speed*dt/1000.0f);
  }
  void accept(const Packet& p){
    if(p.from!=0 || p.kind!=0 || (heard && p.hub==hub && !newer(p.seq,seq)))return;
    // Preserve advisory on RPU restart or link loss; only an explicit matching clear clears it.
    if(p.shieldDevice && (p.shieldDevice!=shieldDevice || p.shieldSeq>shieldSeq ||
       (p.shieldSeq==shieldSeq && (shieldActive || !p.shieldActive)))){
      shieldDevice=p.shieldDevice;shieldSeq=p.shieldSeq;shieldActive=p.shieldActive;shieldAnimal=p.shieldAnimal;
    }
    bool changed=p.hub!=hub;
    if(changed)attached=false;
    uint8_t oldPhase=view.phase;
    hub=p.hub;seq=p.seq;at=ms();heard=true;view=p;
    if(p.boot==boot && p.phase==RESET){
      if(!attached || round!=p.round){position=0;round=p.round;runAt=0;}
      attached=true;
    }
    if(p.boot!=boot || p.round!=round || !attached)view.phase=FAULT;
    if(!radio.restoringPrimary() || (p.boot==boot && p.round==round && attached))radio.accepted(p);
    if(view.phase==RUN && oldPhase!=RUN)runAt=ms();
    reply=Packet{};reply.from=ID;reply.to=0;reply.kind=1;
    reply.hub=hub;reply.seq=seq;reply.boot=boot;pending=true;
  }
  // OLED PRESENTATION ONLY
  static const uint8_t* oledGlyph(char c){
    static const uint8_t font[59][7]={
      {0x0,0x0,0x0,0x0,0x0,0x0,0x0},
      {0x20,0x20,0x20,0x20,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x60,0x90,0x90,0x60,0xA8,0x90,0x68},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x10,0x20,0x40,0x40,0x40,0x20,0x10},
      {0x40,0x20,0x10,0x10,0x10,0x20,0x40},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x0,0x0,0x0,0xf8,0x0,0x0,0x0},
      {0x0,0x0,0x0,0x0,0x0,0x20,0x20},
      {0x8,0x8,0x10,0x20,0x40,0x80,0x80},
      {0x70,0x88,0x98,0xa8,0xc8,0x88,0x70},
      {0x20,0x60,0x20,0x20,0x20,0x20,0x70},
      {0x70,0x88,0x8,0x10,0x20,0x40,0xf8},
      {0xf0,0x8,0x8,0x70,0x8,0x8,0xf0},
      {0x10,0x30,0x50,0x90,0xf8,0x10,0x10},
      {0xf8,0x80,0x80,0xf0,0x8,0x8,0xf0},
      {0x70,0x80,0x80,0xf0,0x88,0x88,0x70},
      {0xf8,0x8,0x10,0x20,0x40,0x40,0x40},
      {0x70,0x88,0x88,0x70,0x88,0x88,0x70},
      {0x70,0x88,0x88,0x78,0x8,0x8,0x70},
      {0x0,0x20,0x20,0x0,0x20,0x20,0x0},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x8,0x10,0x20,0x0,0x20},
      {0x70,0x88,0x88,0xf8,0x88,0x88,0x88},
      {0xf0,0x88,0x88,0xf0,0x88,0x88,0xf0},
      {0x78,0x80,0x80,0x80,0x80,0x80,0x78},
      {0xf0,0x88,0x88,0x88,0x88,0x88,0xf0},
      {0xf8,0x80,0x80,0xf0,0x80,0x80,0xf8},
      {0xf8,0x80,0x80,0xf0,0x80,0x80,0x80},
      {0x78,0x80,0x80,0xb8,0x88,0x88,0x78},
      {0x88,0x88,0x88,0xf8,0x88,0x88,0x88},
      {0xf8,0x20,0x20,0x20,0x20,0x20,0xf8},
      {0x38,0x10,0x10,0x10,0x90,0x90,0x60},
      {0x88,0x90,0xa0,0xc0,0xa0,0x90,0x88},
      {0x80,0x80,0x80,0x80,0x80,0x80,0xf8},
      {0x88,0xd8,0xa8,0xa8,0x88,0x88,0x88},
      {0x88,0xc8,0xc8,0xa8,0x98,0x98,0x88},
      {0x70,0x88,0x88,0x88,0x88,0x88,0x70},
      {0xf0,0x88,0x88,0xf0,0x80,0x80,0x80},
      {0x70,0x88,0x88,0x88,0xa8,0x90,0x68},
      {0xf0,0x88,0x88,0xf0,0xa0,0x90,0x88},
      {0x78,0x80,0x80,0x70,0x8,0x8,0xf0},
      {0xf8,0x20,0x20,0x20,0x20,0x20,0x20},
      {0x88,0x88,0x88,0x88,0x88,0x88,0x70},
      {0x88,0x88,0x88,0x88,0x88,0x50,0x20},
      {0x88,0x88,0x88,0xa8,0xa8,0xd8,0x88},
      {0x88,0x88,0x50,0x20,0x50,0x88,0x88},
      {0x88,0x88,0x50,0x20,0x20,0x20,0x20},
      {0xf8,0x8,0x10,0x20,0x40,0x80,0xf8}
    };
    return font[(c>=32 && c<=90)?c-32:'?'-32];
  }
  void icon(uint8_t k,int x=40,int y=36){
    static const uint8_t bits[8][156]={
{0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1f,0xff,0xff,0xf0,0x0,0x0,0x3f,0xff,0xff,0xf8,0x0,0x0,0x38,0x0,0x0,0x38,0x0,0x0,0x70,0x0,0x0,0x1c,0x0,0x0,0x70,0x0,0x0,0x1e,0x0,0x0,0xe0,0x0,0x0,0xe,0x0,0x0,0xe0,0x0,0x0,0xf,0x0,0x1,0xc0,0x0,0x0,0x7,0x80,0x1,0xc0,0x0,0x0,0x7,0x80,0x1f,0x80,0x0,0x0,0x3,0xf8,0x1f,0xff,0xff,0xff,0xff,0xf8,0x3,0xff,0xff,0xff,0xff,0xc0,0x3,0x80,0xff,0xff,0x81,0xc0,0x3,0x80,0xff,0xff,0x81,0xc0,0x3,0x80,0xff,0xff,0x81,0xc0,0x3,0xff,0xff,0xff,0xff,0xc0,0x3,0xff,0xff,0xff,0xff,0xc0,0x3,0xff,0xc0,0x3,0xff,0xc0,0x0,0xfe,0x0,0x0,0x7f,0x0,0x0,0xfe,0x0,0x0,0x7f,0x0,0x0,0xfe,0x0,0x0,0x7f,0x0,0x0,0xfe,0x0,0x0,0x7f,0x0},
{0x0,0x0,0x0,0x0,0x0,0x0,0xf,0xef,0xef,0xe0,0x0,0x0,0xf,0xef,0xef,0xe0,0x0,0x0,0xf,0xef,0xef,0xe0,0x0,0x0,0xf,0xef,0xef,0xe0,0x0,0x0,0x3f,0xff,0xff,0xfc,0x0,0x0,0x3f,0xff,0xff,0xfc,0x0,0x0,0x3f,0xff,0xff,0xfc,0x0,0x0,0x3f,0xff,0xff,0xfd,0xff,0x80,0x3f,0xff,0xff,0xfd,0xff,0xc0,0x3f,0xff,0xff,0xfd,0x80,0xc0,0x3f,0xff,0xff,0xfd,0x80,0x60,0x3f,0xff,0xff,0xfd,0x80,0x70,0x3f,0xff,0xff,0xfd,0x80,0x38,0x3f,0xff,0xff,0xfd,0x80,0x38,0x3f,0xff,0xff,0xfd,0x80,0x1c,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x27,0x1c,0x38,0xe0,0x38,0xec,0x6,0xc,0x30,0x61,0xf0,0x7c,0x6,0xc,0x30,0x60,0x30,0x60,0x7,0x1c,0x38,0xe0,0x38,0xe0,0x3,0xf8,0x1f,0xc0,0x1f,0xc0,0x0,0xe0,0x7,0x0,0x7,0x0},
{0x0,0x0,0x3f,0xfc,0x0,0x0,0x0,0x0,0x3f,0xfc,0x0,0x0,0x0,0x0,0x3f,0xfc,0x0,0x0,0x0,0x1f,0xff,0xff,0xf8,0x0,0x0,0x3f,0xff,0xff,0xfc,0x0,0x0,0x3f,0xff,0xff,0xfc,0x0,0x0,0x70,0x0,0x0,0xe,0x0,0x0,0xf0,0x0,0x0,0xf,0x0,0x0,0xf0,0x0,0x0,0xf,0x0,0x0,0xf0,0x0,0x0,0xf,0x0,0x0,0xf0,0x0,0x0,0xf,0x0,0x0,0xf0,0x0,0x0,0xf,0x0,0x0,0xf0,0x0,0x0,0xf,0x0,0x0,0xff,0xff,0xff,0xff,0x0,0x0,0xff,0xfc,0x3f,0xff,0x0,0x0,0xff,0xfc,0x3f,0xff,0x0,0x0,0xff,0xe0,0x7,0xff,0x0,0x0,0xc1,0xe0,0x7,0x83,0x0,0x0,0xc1,0xe0,0x7,0x83,0x0,0x0,0xc1,0xfc,0x3f,0x83,0x0,0x0,0xff,0xfc,0x3f,0xff,0x0,0x0,0xff,0xfc,0x3f,0xff,0x0,0x0,0xff,0xff,0xff,0xff,0x0,0x0,0x3f,0x0,0x0,0xfc,0x0,0x0,0x3f,0x0,0x0,0xfc,0x0,0x0,0x3f,0x0,0x0,0xfc,0x0},
{0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x3f,0xff,0xff,0xfc,0x7f,0x0,0x3f,0xff,0xff,0xfc,0x7f,0x0,0x31,0x4,0x10,0x4c,0x7f,0x0,0x31,0x4,0x10,0x4d,0xff,0x80,0x31,0x4,0x10,0x4d,0xff,0xc0,0x31,0x4,0x10,0x4d,0x80,0xc0,0x31,0x4,0x10,0x4d,0x80,0x60,0x31,0x4,0x10,0x4d,0x80,0x70,0x3f,0xff,0xff,0xfd,0x80,0x38,0x3f,0xff,0xff,0xfd,0x80,0x38,0x3f,0xff,0xff,0xfd,0x80,0x1c,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x27,0x1c,0x38,0xe0,0x38,0xec,0x6,0xc,0x30,0x61,0xf0,0x7c,0x6,0xc,0x30,0x60,0x30,0x60,0x7,0x1c,0x38,0xe0,0x38,0xe0,0x3,0xf8,0x1f,0xc0,0x1f,0xc0,0x0,0xe0,0x7,0x0,0x7,0x0},
{0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x3f,0xff,0xff,0xfc,0x0,0x0,0x3f,0xff,0xff,0xfc,0x0,0x0,0x30,0x0,0x0,0xc,0x0,0x0,0x30,0x0,0x0,0xd,0xff,0x80,0x30,0x0,0x0,0xd,0xff,0xc0,0x30,0x0,0x0,0xd,0x80,0xc0,0x30,0x0,0x0,0xd,0x80,0x60,0x30,0x0,0x0,0xd,0x80,0x70,0x30,0x0,0x0,0xd,0x80,0x38,0x30,0x0,0x0,0xd,0x80,0x38,0x30,0x0,0x0,0xd,0x80,0x1c,0x30,0x0,0x0,0xd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x3f,0xff,0xff,0xfd,0xff,0xfc,0x27,0x1c,0x38,0xe0,0x38,0xec,0x6,0xc,0x30,0x61,0xf0,0x7c,0x6,0xc,0x30,0x60,0x30,0x60,0x7,0x1c,0x38,0xe0,0x38,0xe0,0x3,0xf8,0x1f,0xc0,0x1f,0xc0,0x0,0xe0,0x7,0x0,0x7,0x0},
{0x0,0x0,0x0,0x40,0x0,0x0,0x0,0x0,0x0,0x40,0x0,0x0,0x0,0x0,0x0,0xe0,0x0,0x0,0x0,0x0,0x0,0xe0,0x0,0x0,0x0,0x0,0x1,0xf0,0x0,0x0,0x0,0x0,0x1,0xf0,0x0,0x0,0x0,0x20,0x3,0xf8,0x0,0x0,0x0,0x20,0x3,0xf8,0x0,0x0,0x0,0x70,0x7,0xfc,0x0,0x0,0x0,0x70,0x7,0xfc,0x1,0x0,0x0,0xf8,0x7,0xfc,0x1,0x0,0x0,0xf8,0xf,0xfe,0x3,0x80,0x1,0xfc,0xf,0xfe,0x3,0x80,0x1,0xfc,0x1f,0xff,0x7,0xc0,0x3,0xfe,0x3f,0xff,0x87,0xc0,0x3,0xfe,0xf,0xfe,0xf,0xe0,0x3,0xfe,0x1f,0xff,0xf,0xe0,0x7,0xff,0x3f,0xff,0x9f,0xf0,0x7,0xff,0x7f,0xff,0xdf,0xf0,0xf,0xff,0xff,0xff,0xff,0xf0,0x1f,0xff,0xc0,0x60,0x3f,0xf8,0x7,0xff,0x0,0x60,0x3f,0xf8,0xf,0xff,0x80,0x60,0x7f,0xfc,0x1f,0xff,0xc0,0x60,0xff,0xfe,0x3f,0xff,0xe0,0x60,0x3f,0xf8,0x7f,0xff,0xf0,0x0,0x7f,0xfc},
{0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x7e,0x0,0x0,0x3,0xff,0x0,0x7f,0x0,0x0,0x3f,0xff,0xf1,0xbf,0x80,0x0,0xff,0xff,0xf7,0xdf,0xc0,0x1,0xff,0xff,0xef,0xed,0xe0,0x3,0xff,0xff,0xef,0xef,0xe0,0x7,0xff,0xff,0xef,0xef,0xe0,0xf,0xff,0xff,0xef,0xef,0xe0,0xf,0xff,0xff,0xf7,0xdf,0xe0,0xf,0xff,0xff,0xfb,0xbf,0xe0,0xf,0xff,0xff,0xfc,0x7f,0xe0,0x17,0xff,0xff,0xff,0xff,0xe0,0x13,0xff,0xff,0xff,0xfe,0xe0,0x21,0xff,0xff,0xff,0xe0,0x60,0x20,0xff,0xff,0xfd,0xe0,0x70,0x40,0xff,0xff,0xfd,0xe0,0x70,0x40,0xf3,0xff,0x3d,0xe0,0x70,0x0,0xf0,0xf0,0x3d,0xe0,0x70,0x0,0xf0,0xf0,0x3d,0xe0,0x70,0x0,0xf0,0xf0,0x3d,0xe0,0x7e,0x0,0xf0,0xf0,0x3d,0xe0,0x7e,0x0,0xf0,0xf0,0x3d,0xe0,0x3e,0x0,0xf0,0xf0,0x3d,0xe0,0x0},
{0x0,0x3,0xff,0xff,0xe0,0x0,0x0,0xf,0xf0,0x7,0xf8,0x0,0x0,0x1f,0x80,0x0,0xfc,0x0,0x0,0x7c,0x0,0x0,0x1f,0x0,0x0,0xf8,0x0,0x0,0xf,0x80,0x1,0xe0,0x7,0xf0,0x3,0xc0,0x3,0xc0,0x3f,0xfe,0x1,0xe0,0x3,0x80,0xff,0xff,0x80,0xe0,0x7,0x1,0xf8,0xf,0xc0,0x70,0x3,0x3,0xc0,0x1,0xe0,0x40,0x0,0x7,0x80,0x0,0xf0,0x0,0x0,0xe,0x0,0x0,0x38,0x0,0x0,0x1e,0x3,0xe0,0x3c,0x0,0x0,0xc,0xf,0xf8,0x10,0x0,0x0,0x0,0x1f,0xfc,0x0,0x0,0x0,0x0,0x3c,0x1e,0x0,0x0,0x0,0x0,0x78,0xf,0x0,0x0,0x0,0x0,0x30,0x6,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1,0xc0,0x0,0x0,0x0,0x0,0x3,0xe0,0x0,0x0,0x0,0x0,0x3,0xe0,0x0,0x0,0x0,0x0,0x3,0xe0,0x0,0x0,0x0,0x0,0x1,0xc0,0x0,0x0}
    };
    oled.drawBitmap(x,y,bits[k<8?k:0],48,26,SSD1306_WHITE);
  }
  void text(int y,const char* value,int scale=1){
    int n=strlen(value),x=(128-(n*6-1)*scale)/2;
    for(int i=0;i<n;i++){
      const uint8_t* glyph=oledGlyph(value[i]);
      for(int row=0;row<7;row++)for(int col=0;col<5;col++)if(glyph[row]&(0x80>>col))
        oled.fillRect(x+i*6*scale+col*scale,y+row*scale,scale,scale,SSD1306_WHITE);
    }
  }
  uint8_t vehicleIcon(){switch((Type)view.ownType){
    case TRUCK:return 1;case EMPTY:return 4;case AMBULANCE:return 2;case FIRE:return 3;default:return 0;}}
  uint8_t displayStage(){
    // Only interpolate time within the RPU's current scenario; never advance its ID.
    if(view.stage==3)return 3;
    if(view.phase!=RUN)return 0;
    uint32_t elapsed=view.sceneElapsed+(ms()-at);
    if(elapsed>=SCENARIO_MS)return 1; // Await the RPU's safe next-round handshake.
    return elapsed/DISPLAY_STAGE_MS;
  }
  const char* action(){
    if(!moving())return "WAIT";
    if(slow())return "SLOW";
    if(view.scene==7 && radio.usingWiFi() && radio.wifiConfirmed())return "RESUME";
    return "GO";
  }
  bool safetyPage(){return !fresh() || !attached || view.phase==FAULT ||
    (view.phase==RUN && ms()-at>=view.ttl) || view.reason==WILDLIFE ||
    view.reason==SENSOR || view.reason==FSU_LOST || view.reason==LINK ||
    view.reason==MPU_CHECK || view.reason==RESTART;}
  void road(){
    oled.drawLine(43,35,27,63,SSD1306_WHITE);oled.drawLine(85,35,101,63,SSD1306_WHITE);
    // Keep lane lines behind the vehicle silhouette.
    oled.fillRect(40,36,48,26,SSD1306_BLACK);icon(vehicleIcon());
    if(moving() && !slow()){
      oled.fillTriangle(108,32,102,41,114,41,SSD1306_WHITE);
      oled.fillRect(106,41,5,13,SSD1306_WHITE);
    }
  }
  void preview(){
    char next[12];snprintf(next,sizeof(next),"NEXT: S%u",view.nextScene+1);text(1,next);
    switch(view.nextScene){
      case 0:text(12,"NORMAL");text(22,"TWO-WAY TRAFFIC");text(32,"(CAR VS CAR)");icon(0,40,38);break;
      case 1:text(14,"EMPTY TRUCK");text(25,"VS CAR");icon(4);break;
      case 2:text(14,"LOADED TRUCK");text(25,"VS CAR");icon(1);break;
      case 3:text(14,"TWO LOADED");text(25,"TRUCKS");icon(1,12,36);icon(1,68,36);break;
      case 4:text(14,"AMBULANCE");text(25,"VS CAR");icon(2);break;
      case 5:text(14,"EMERGENCY");text(25,"CONFLICT");icon(2,12,36);icon(3,68,36);break;
      case 6:text(14,"FOREST &");text(25,"WILDLIFE");icon(5);break;
      case 7:text(12,"LORA FAILURE");text(22,"AND WI-FI");text(30,"RECOVERY");icon(7,40,38);break;
    }
  }
  void render(){
    oled.clearDisplay();oled.setTextColor(SSD1306_WHITE);oled.setTextSize(1);
    oled.setCursor(0,0);oled.printf("OBU%u  S%u",ID,view.scene+1);
    oled.setCursor(88,0);oled.print(radio.usingWiFi()?(radio.wifiConfirmed()?"WIFI":"LINK?"):(radio.restoringPrimary()?"PROBE":radio.loraReady()?"LORA":"NO RF"));
    oled.drawLine(0,10,127,10,SSD1306_WHITE);
    const char* current=!fresh()?"LINK LOST":!attached?"SYNC":view.phase==FAULT?"FAULT":
      pos()>=FINISH?"CLEAR":action();
    text(16,current,strlen(current)>6?1:2);
    const char* why=!fresh()?"WAIT FOR RPU":view.reason<=COMPLETE?reasons[view.reason]:"SYNC";
    if(shieldActive){text(36,shieldAnimal==1?"BIG CAT AHEAD":"ELEPHANT AHEAD");text(49,shieldAnimal==1?"KEEP DISTANCE":"NO HORN / ADVISORY");}else{
    text(36,why);
    if(view.scene==3){oled.setCursor(0,49);if(tilt.state()==2)oled.printf("PITCH %+5.1f",tilt.pitch);else oled.print("MPU CHECK");}
    else {oled.setCursor(0,49);oled.print(types[view.ownType<=EMPTY?view.ownType:CAR]);}
    }
    oled.drawRect(0,60,128,4,SSD1306_WHITE);oled.fillRect(1,61,(uint16_t)(126UL*pos()/FINISH),2,SSD1306_WHITE);
    // Current action always visible. No next-scene page during an active crossing.
    if(moving()){int x=110+(ms()/180)%8;oled.fillTriangle(x,44,x-5,48,x-5,40,SSD1306_WHITE);}
    oled.display();
  }
  void draw(){if(!screen || ms()-drawAt<150)return;drawAt=ms();render();}
  // END OLED PRESENTATION ONLY.

  void loop(){
    radio.tick();advance();Packet p;while(radio.read(p))accept(p);
    if(pending && ms()-at>=15){
      if(ms()-at>=180)pending=false;
      else{
        reply.shieldDevice=shieldDevice;reply.shieldSeq=shieldSeq;reply.shieldActive=shieldActive;reply.shieldAnimal=shieldAnimal;
        reply.round=round;reply.scene=view.scene;reply.pos=pos();reply.mpu=tilt.state();
        reply.phase=view.phase;reply.reason=view.reason;reply.limit=view.limit;reply.ttl=view.ttl;
        reply.motion=moving()?(slow()?DISPLAY_SLOW:DISPLAY_GO):DISPLAY_WAIT;
        reply.ownType=view.ownType;reply.stage=displayStage();reply.sceneElapsed=view.sceneElapsed;
        uint32_t sensorAge=tilt.sampleAge();reply.age=sensorAge>65535?65535:sensorAge;
        reply.sampleSeq=tilt.sampleSeq;reply.p2p=tilt.problem();reply.rms10=tilt.count;reply.hz10=tilt.lastCalIssue;
        reply.pitch=reply.roll=0; // Never reuse an earlier valid angle in an invalid report.
        if(reply.mpu==2){reply.pitch=lroundf(tilt.pitch*100);reply.roll=lroundf(tilt.roll*100);}
        if(radio.send(reply))pending=false;
      }
    }
    // MPU is I2C; LoRa TX uses SPI. Service fresh samples during TX as well,
    // but never delay a pending reply with an I2C transaction.
    if(!pending)tilt.tick();
    // If the MPU could not initialize at boot (e.g. sensor powered up late),
    // retry automatically every 3 s. Once found, it calibrates in the background
    // and never times out; C remains an optional manual re-zero only.
    if(!pending && !radio.busy && !tilt.ok && ms()-mpuRetryAt>=3000){
      mpuRetryAt=ms();
      Serial.println("MPU AUTO RETRY: checking sensor; no manual calibration command required");
      tilt.begin();
    }
    if(!pending && !radio.busy){
      if(Serial.available()){char c=Serial.read();if(c=='C'||c=='c')tilt.begin();else if(c=='F'||c=='f')radio.testFailover();}
      draw();
    }
    if(ms()-logAt>=1000){logAt=ms();tilt.report();Serial.printf(
      "OBU%u zone=%s SIMcm=%.1f signal=%s reason=%s pitch=%.1f mpu=%u link=%u\n",
      ID,zone(pos()),position/10,moving()?(slow()?"SLOW":"GO"):"WAIT",
      reasons[view.reason],tilt.state()==2?tilt.pitch:NAN,tilt.state(),fresh());}
    if(!radio.usingWiFi() && ms()-diagAt>=3000){
      diagAt=ms();radio.diagnostics();
      if(!fresh())Serial.println(radio.loraReady()?
        "NO VALID RPU LORA POLL: init OK; check RPU TX/DIO0, matching four sketches and RF settings/antennas. WIFI STANDBY.":
        "WAIT LORA INIT: inspect RegVersion/power/SPI. WIFI STANDBY.");
    }
    delay(1);
  }
};
Controller app;
}
void setup(){Demo::app.setup();}
void loop(){Demo::app.loop();}
